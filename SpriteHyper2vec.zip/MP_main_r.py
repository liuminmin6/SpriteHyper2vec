import hypernetx as hnx
from args import args_parser
from node2vec import node2vec
import os
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from itertools import combinations
import time
import multiprocessing
import eventlet
from scc2 import get_scc2


def get_file_name(file_dir):
    L = []
    for root, dirs, files in os.walk(file_dir):
        for file in files:
            L.append(file)
    return L


def node2vec_MP(file, chr_key, chr, file_dir, re):
    # if chr_key in done: return
    try:
        with eventlet.Timeout(1000000000, True):
            args = args_parser()
            scSCRIPE_dir = file_dir + '\\filtered_1000_cells_single_cell_files'
            HiC_node2vec_dir = file_dir + '\\HiC_node2vec'
            starttime = time.time()
            Multiple_interactions = get_Multiple_interactions(chr_key, scSCRIPE_dir, file, re, chr)
            raw_output = get_raw(chr, re, Multiple_interactions)
            savetxt(HiC_node2vec_dir, file, raw_output, chr_key, re, raw=True)
            #savejpg(HiC_node2vec_dir, file, raw_output, chr_key, re, raw=True)
            if np.all(raw_output == 0):
                output = raw_output
                savetxt(HiC_node2vec_dir, file, output, chr_key, re)
                #savejpg(HiC_node2vec_dir, file, output, chr_key, re)
            else:
                Multiple_interactions_hypergraph = hypergraph_build(Multiple_interactions)
                G = Multiple_interactions_hypergraph
                vec = node2vec(args, G, chr, file, chr_key)
                output = vec.learning_features()
                savetxt(HiC_node2vec_dir, file, output, chr_key, re, raw=False)
                #savejpg(HiC_node2vec_dir, file, output, chr_key, re)
            endtime = time.time()
            costtime = endtime - starttime
            fig(file_dir, file, chr_key, re)
            print(file + '_' + chr_key + '_' + 'costtime = ' + str(costtime))
    except eventlet.timeout.Timeout:
        return log(file, chr_key, file_dir)
    else:
        return costtime


def node2vec_MP_MC(chr_key, chr, file_dir, re, num):
    # if chr_key in done: return
    files = []
    f1 = open('re_file.txt', 'r', encoding='utf-8')
    while True:
        line = f1.readline()
        if not line : break
        files.append(f1.readline().strip('\n'))
    f1.close()
    args = args_parser()
    scSCRIPE_dir = file_dir + '\\filtered_1000_cells_single_cell_files'
    starttime = time.time()
    Multiple_interactions = get_Multiple_interactions_MC(chr_key, scSCRIPE_dir, files, re, chr)
    raw_output = get_raw(chr, re, Multiple_interactions)
    savetxt_MC(file_dir, files, raw_output, chr_key, re, num, raw=True)
    # savejpg(HiC_node2vec_dir, file, raw_output, chr_key, re, raw=True)
    if np.all(raw_output == 0):
        output = raw_output
        savetxt_MC(file_dir, files, output, chr_key, re, num)
        # savejpg(HiC_node2vec_dir, file, output, chr_key, re)
    else:
        Multiple_interactions_hypergraph = hypergraph_build(Multiple_interactions)
        G = Multiple_interactions_hypergraph
        vec = node2vec(args, G, chr, files, chr_key)
        output = vec.learning_features()
        savetxt_MC(file_dir, files, output, chr_key, re, num)
        # savejpg(HiC_node2vec_dir, file, output, chr_key, re)
    fig_on(output, raw_output, num, chr_key, re)
    endtime = time.time()
    costtime = endtime - starttime
    print(num + '_' + chr_key + '_' + 'costtime = ' + str(costtime))
    return costtime


def raw_add_all(chr_key, file_dir, chr, re=100000):
    scSCRIPE_dir = file_dir + '\\filtered_1000_cells_single_cell_files'
    files = get_file_name(scSCRIPE_dir)
    output_raw = np.zeros((chr // re + 1, chr // re + 1))
    name = 'raw_all' + '_' + str(re)
    print('get raw_add_all now!')
    for file in files:
        print(file)
        name_raw = 'raw_' + chr_key + '_' + str(re)
        raw_dir = file_dir + '\\HiC_node2vec\\' + file + '\\' + chr_key + '\\' + name_raw + '.matrix.gz'
        Multiple_interactions = get_Multiple_interactions(chr_key, scSCRIPE_dir, file, re, chr)
        raw_output = get_raw(chr, re, Multiple_interactions)
        output_raw += raw_output
    np.savetxt(name + '.matrix.gz', output_raw, fmt='%.3f', delimiter=" ")
    return output_raw


def cell_add(chr_key, file_dir, chr, re=100000):
    scSCRIPE_dir = file_dir + '\\filtered_1000_cells_single_cell_files'
    output = np.zeros((chr // re + 1, chr // re + 1))
    output_raw = np.zeros((chr // re + 1, chr // re + 1))
    raw_all = np.loadtxt('raw_all'+'_'+str(re)+'.txt')
    raw_all = raw_all[(chr // re + 1):, (chr // re + 1):]
    f2 = open('re_file.txt', 'r', encoding='utf-8')
    f1 = open('p123_' + str(re) + '.txt', 'w', encoding='utf-8')
    while True:
        file = f2.readline().strip('\n')
        if not file: break
        if not Result_record(file_dir, chr_key, file, re): continue
        name = file + '_' + chr_key + '_' + str(re)
        node_dir = file_dir + '\\HiC_node2vec\\' + file + '\\' + chr_key + '\\' + name + '.matrix.gz'
        Multiple_interactions = get_Multiple_interactions(chr_key, scSCRIPE_dir, file, re, chr)
        print('get_Multiple_interactions')
        raw_output = get_raw(chr, re, Multiple_interactions)
        output_raw += raw_output
        o = np.loadtxt(node_dir)
        if o.shape != output.shape:continue
        output += o
        a1, a2 = get_scc2(raw_output, raw_all, chr // re + 1)
        b1, b2 = get_scc2(o, raw_all, chr // re + 1)
        if b1/a1 >= 1:
            q = str(a1) + ' ' + str(b1) + ' ' + file
        #else: q = str(a1) + ' ' + str(b1)
            f1.write(q)
            f1.write('\n')
            print(q)
        else: print('未提升', str(a1) + ' ' + str(b1) + ' ' + file)
    a1, a2 = get_scc2(output_raw, raw_all, chr // re + 1)
    b1, b2 = get_scc2(output, raw_all, chr // re + 1)
    q = str(a1) + ' ' + str(b1)
    f1.write(q)
    f1.write('\n')
    f1.close()
    f2.close()
    return


def log(file, chr_key, file_dir):
    H_dir = file_dir + '\\' + file
    #name = file + '_' + chr_key
    Timeout = 'Timeout error'
    f = open(H_dir + '\\' + chr_key + '\\' + 'timeout.txt', 'a', encoding='utf-8')
    f.write(Timeout)
    f.close()
    return print(Timeout)


def loginfo(file, chr, file_dir):
    HiC_node2vec_dir = file_dir + '\\HiC_node2vec'
    f_info = open(HiC_node2vec_dir + '\\' + 'loginfo.txt', 'a', encoding='utf-8')
    f_info.write(file + ' ' + chr + '\n')
    f_info.close()
    return


def loginfo_MP(map_all, file):
    return loginfo(file, map_all[1], map_all[3])


def node2vec_MP_invalue(map_all):
    return node2vec_MP(map_all[0], map_all[1], map_all[2], map_all[3], map_all[4])


def get_all_map(file_dir, re):
    # 获取所有染色体长度
    # scSCRIPE_dir = file_dir + '\\filtered_1000_cells_single_cell_files'
    # files = get_file_name(scSCRIPE_dir)
    # np.random.shuffle(files)
    f_chr = open(file_dir + '\\' + 'mm9.txt')
    chr = []
    f1 = open('re_file.txt', 'r', encoding='utf-8')
    while True:
        line = f_chr.readline()
        if not line:
            break
        while True:
            file = f1.readline().strip('\n')
            if not file:
                break
            a = line.strip().split()
            if not Result_record(file_dir, a[0], file, re):chr.append((file, a[0], int(a[1]), file_dir, re))
            #chr.append((file, a[0], int(a[1])//2, file_dir, re))
    f1.close()
    f_chr.close()
    print('未完成的chr条目数：', len(chr))
    #raw_add_all('chr1', file_dir, chr, re)
    return chr


def Result_record(file_dir, chr_key, file, re=100000):
    HiC_node2vec_dir = file_dir + '\\HiC_node2vec'
    chr_dir = HiC_node2vec_dir + '\\' + file + '\\' + chr_key + '\\' + file + '_' + chr_key + '_' + str(re) + '.matrix.gz'
    if os.path.isfile(chr_dir):
        f = open(chr_dir, 'r', encoding='utf-8')
        read_data = f.readline()
        f.close()
        if read_data == 'Timeout error':
            return False
        else: return True
    return False


def get_chr(file_dir):
    # 获取所有染色体长度
    f_chr = open(file_dir + '\\' + 'mm9.txt')
    chr = {}
    while True:
        line = f_chr.readline()
        if not line:
            break;
        a = line.strip().split()
        chr[a[0]] = int(a[1])
    f_chr.close()
    return chr


def get_Multiple_interactions(chr_key, scSCRIPE_dir, file, re, chr):
    f = open(scSCRIPE_dir + '\\' + file, 'r', encoding='utf-8')
    Multiple_interactions = {}
    idx = 0
    while True:
        line = f.readline()
        if not line:
            break;
        a = line.strip().split()
        if len(a) < 3:
            continue
        del a[0]
        i = 0
        b = []
        for obj in a:
            if len(chr_key) <= 4:
                if obj[:5] == chr_key + ':' and int(obj[5:]) <= chr:
                    b.append(str(int(obj[5:]) // re))  # 取100k为分辨率
                    i += 1
            else:
                if obj[:6] == chr_key + ':' and int(obj[5:]) <= chr:
                    b.append(str(int(obj[6:]) // re))  # 取100k为分辨率
                    i += 1
        b = list(set(b))
        if not b or len(b) < 2:
            continue
        if len(b) >= 1000: continue
        Multiple_interactions[idx] = b
        idx += 1
    f.close()
    return Multiple_interactions


def get_Multiple_interactions_MC(chr_key, scSCRIPE_dir, files, re, chr):
    Multiple_interactions = {}
    for file in files :
        f = open(scSCRIPE_dir + '\\' + file, 'r', encoding='utf-8')
        idx = 0
        while True:
            line = f.readline()
            if not line:
                break;
            a = line.strip().split()
            if len(a) < 3:
                continue
            del a[0]
            i = 0
            b = []
            for obj in a:
                if len(chr_key) <= 4:
                    if obj[:5] == chr_key + ':' and int(obj[5:]) <= chr:
                        b.append(str(int(obj[5:]) // re))  # 取100k为分辨率
                        i += 1
                else:
                    if obj[:6] == chr_key + ':' and int(obj[5:]) <= chr:
                        b.append(str(int(obj[6:]) // re))  # 取100k为分辨率
                        i += 1
            b = list(set(b))
            if not b or len(b) < 2:
                continue
            if len(b) >= 1000: continue
            Multiple_interactions[idx] = b
            idx += 1
        f.close()
    return Multiple_interactions


def hypergraph_build(Multiple_interactions):
    Multiple_interactions_hypergraph = hnx.Hypergraph(Multiple_interactions)
    print('Multiple_interactions_hypergraph done!')
    return Multiple_interactions_hypergraph


def mkdir(file_dir, file):
    # filelist = os.path.
    if not os.path.exists(file_dir + '\\' + file):
        os.makedirs(file_dir + '\\' + file)


def savetxt(file_dir, file, output, chr_key, re, raw=False):
    h_dir = file_dir
    H_dir = file_dir + '\\' + file
    if raw:
        name = 'raw_' + chr_key + '_' + str(re)
    else:
        name = file + '_' + chr_key + '_' + str(re)
    mkdir(h_dir, file)
    mkdir(H_dir, chr_key)
    print('savetxt the features now', 'name: ', file, name)
    np.savetxt(H_dir + '\\' + chr_key + '\\' + name + '.matrix.gz', output, fmt='%.3f', delimiter=" ")
    return

def savetxt_MC(file_dir, files, output, chr_key, re, num, raw=False):
    if raw:
        name = 'raw_' + chr_key + '_' + str(re)
    else:
        name = 'node' + '_' + chr_key + '_' + str(re)
    H_dir = file_dir + '\\add_cell'
    mkdir(H_dir, str(num))
    mkdir(H_dir, chr_key)
    print('savetxt the features now', 'num: ', num)
    np.savetxt(H_dir + '\\' + str(num) + '\\' + chr_key + '\\' + name + '.matrix.gz', output, fmt='%.3f', delimiter=" ")
    with open(H_dir + '\\' + str(num) + '\\' + chr_key + '\\' + 're_file.txt', 'w', encoding='utf-8') as f:
        for file in files:
            f.write(file + '\n')
    return


def add_savejpg(file_dir, num, round, chr_key, output, re=100000):
    h_dir = file_dir + '\\add_cell'
    H_dir = file_dir + '\\add_cell' + '\\' + str(num)
    save_dir = file_dir + '\\add_cell' + '\\' + str(num) + '\\' + chr_key
    mkdir(h_dir, str(num))
    mkdir(H_dir, chr_key)
    mkdir(save_dir, str(round))
    print('savejpg the features now')
    plt.figure(dpi=120)
    sns.heatmap(output, cmap='cubehelix', vmin=0, vmax=num, cbar=False)
    plt.xlabel(str(re) + '_' + str(round))
    plt.ylabel('bins')
    plt.savefig(save_dir + '\\' + str(round) + '.jpg')
    plt.close()


def savejpg(file_dir, file, output, chr_key, re=100000, raw=False):
    h_dir = file_dir
    H_dir = file_dir + '\\' + file
    if raw:
        name = 'raw_' + chr_key + '_' + str(re)
    else:
        name = file + '_' + chr_key + '_' + str(re)
    mkdir(h_dir, file)
    mkdir(H_dir, chr_key)
    print('savejpg the features now, name: ', file, name)
    plt.figure(dpi=120)
    sns.heatmap(output, cmap='cubehelix', vmin=0, vmax=1, cbar=False)
    plt.xlabel(str(re) + '_' + name)
    plt.ylabel('bins')
    plt.savefig(H_dir + '\\' + chr_key + '\\' + name + '.jpg')
    plt.close()


def randomfile(file_dir, r):
    scSCRIPE_dir = file_dir + '\\filtered_1000_cells_single_cell_files'
    files = get_file_name(scSCRIPE_dir)
    np.random.shuffle(files)
    i = 0
    if r >= len(files): r = len(files)
    with open('re_file.txt', 'w', encoding='utf-8') as f:
        for file in files:
            if i >= r: break
            f.write(file + '\n')
            i += 1
    return


def fig(file_dir, file, chr_key, re=100000):
    if Result_record(file_dir, chr_key, file, re):
        name = file + '_' + chr_key + '_' + str(re)
        o_dir = file_dir + '\\HiC_node2vec\\' + file + '\\' + chr_key + '\\' + name + '.matrix.gz'
        raw_dir = file_dir + '\\HiC_node2vec\\' + file + '\\' + chr_key + '\\' + 'raw_chr1' + '_' + str(re) + '.matrix.gz'
        data = np.loadtxt(o_dir)
        data1 = np.loadtxt(raw_dir)
        plt.figure(dpi=120)
        data = np.tril(data1, k=0) + np.triu(data, k=0)
        sns.set(font_scale=1.5)
        plt.rc('font', family='Times New Roman', size=12)
        sns.heatmap(data, cmap='hot', vmin=0, vmax=1, cbar=False, center=1)
        plt.xlabel(str(re) + '_' + name)
        plt.ylabel('raw')
        print('save fig now!', file)
        plt.savefig(file_dir + '\\HiC_node2vec\\' + file + '\\' + chr_key + '\\' + '2.jpg')
        plt.close()




def get_raw(chr, re, Multiple_interactions):
    raw_output = np.zeros((chr // re + 1, chr // re + 1))
    for edge in Multiple_interactions.keys():
        if len(Multiple_interactions[edge]) >= 1000: continue
        for bin1, bin2 in combinations(Multiple_interactions[edge], 2):
            raw_output[int(bin1)][int(bin2)] += 1
            raw_output[int(bin2)][int(bin1)] += 1
    return raw_output

'''def a(files):
    file_dir = 'D:\\dataset\\HiC_node2vec'
    chr_key = 'chr1'
    re = args_parser().re
    chr = 197195432
    raw = np.zeros((chr // re + 1, chr // re + 1))
    node = np.zeros((chr // re + 1, chr // re + 1))
    raw_all = np.loadtxt('raw_all.txt')
    for file in files:
        o_dir = file_dir + '\\' + file + '\\' + chr_key + '\\' + file + '_' + chr_key + '.txt'
        r_dir = file_dir + '\\' + file + '\\' + chr_key + '\\' + 'raw_' + chr_key + '.txt'
        raw += np.loadtxt(o_dir)
        node += np.loadtxt(r_dir)
    a1, a2 = get_scc2(raw, raw_all, chr // re + 1)
    b1, b2 = get_scc2(node, raw_all, chr // re + 1)
    del raw
    del node
    with open('scc_defernum.txt', 'a', encoding='utf-8') as f:
        f.write(str(a1) + ' ' + str(b1) + ' ' + str(len(files)) + '\n')
        print(str(a1) + ' ' + str(b1) + ' ' + str(len(files)) + '\n')'''

def add_scnode(num, re):
    file_dir = 'D:\\dataset\\filtered_1000_cells_single_cell_files'
    files = get_file_name(file_dir)
    np.random.shuffle(files)
    files = files[:num]
    raw_output = np.zeros((197195432 // re + 1, 197195432 // re + 1))
    node_output = np.zeros((197195432 // re + 1, 197195432 // re + 1))
    raw_all = np.loadtxt('raw_all_' + str(re) + '.txt')
    for file in files:
        n_dir = 'D:\\dataset\\HiC_node2vec\\' + file + '\\chr1\\' + file + '_chr1_' + str(re) + '.matrix.gz'
        o_dir = 'D:\\dataset\\HiC_node2vec\\' + file + '\\chr1\\' + 'raw' + '_chr1_' + str(re) + '.matrix.gz'
        n = np.loadtxt(n_dir)
        n[n <= 0.7] = 0
        node_output += n
        del n
        raw_output += np.loadtxt(o_dir)
    a1, a2 = get_scc2(node_output, raw_all, 197195432 // re + 1)
    b1, b2 = get_scc2(raw_output, raw_all, 197195432 // re + 1)
    with open('p_' + str(re) + '.txt', 'a', encoding='utf-8') as f:
        f.write(str(a1) + ' ' + str(b1) + '\n')
        print(str(a1) + ' ' + str(b1))
    return

def add_v(a):
    return add_scnode(a[0], a[1])

if __name__ == '__main__':
    '''file_dir = 'D:\\dataset'
    HiC_node2vec_dir = file_dir + '\\HiC_node2vec'
    scSCRIPE_dir = file_dir + '\\filtered_1000_cells_single_cell_files'
    p = multiprocessing.Pool(8)
    re = args_parser().re
    randomfile(file_dir, 1000)
    map_all = get_all_map(file_dir, re)'''
    #node2vec_MP_MC('chr1', 197195432, file_dir, re, 10)
    '''costtime = p.map_async(node2vec_MP_invalue, map_all)
    p.close()
    p.join()'''
    a = []
    num = 50
    for i in range(15):
        for re in [40000]:
            a.append((num, re))
            break
    p = multiprocessing.Pool(8)
    p.map_async(add_v, a)
    p.close()
    p.join()