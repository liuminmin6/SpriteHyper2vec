import hypernetx as hnx
from args import args_parser
from node2vec import node2vec
import os
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from itertools import combinations
import torch
import time

def get_file_name(file_dir):
    L = []
    for root, dirs, files in os.walk(file_dir):
        for file in files:
            L.append(file)
    return L

def main():
    file_dir = 'D:\\dataset'
    chr = get_chr(file_dir)
    args = args_parser()
    scSCRIPE_dir = file_dir + '\\filtered_1000_cells_single_cell_files'
    HiC_node2vec_dir = file_dir + '\\HiC_node2vec'
    files = get_file_name(scSCRIPE_dir)
    for file in files:
        re = args_parser().re
        for chr_key in chr.keys():
            starttime = time.time()
            Multiple_interactions = get_Multiple_interactions('chr2', scSCRIPE_dir, file, re)
            raw_output = get_raw(chr, chr_key, re, Multiple_interactions)
            savetxt(HiC_node2vec_dir, file, raw_output, chr_key, raw=True)
            savejpg(HiC_node2vec_dir, file, raw_output, chr_key, raw=True)
            Multiple_interactions_hypergraph = hypergraph_build(Multiple_interactions)
            G = Multiple_interactions_hypergraph
            vec = node2vec(args, G, chr, chr_key, file)
            output = vec.learning_features()
            savetxt(HiC_node2vec_dir, file, output, chr_key)
            savejpg(HiC_node2vec_dir, file, output, chr_key)
            endtime = time.time()
            costtime = endtime - starttime
            print(file + '_' + chr_key + '_' + 'costtime = ' + str(costtime))
            break
        break
    return

def get_chr(file_dir):
    #获取所有染色体长度
    f_chr = open(file_dir + '\\' + 'mm9.txt')
    chr = {}
    while True:
        line = f_chr.readline()
        if not line:
            break;
        a = line.strip().split()
        chr[a[0]] = int(a[1])
    f_chr.close()
    return chr

def get_Multiple_interactions(chr, scSCRIPE_dir, file, re):
    f = open(scSCRIPE_dir + '\\' + file, 'r', encoding='utf-8')
    Multiple_interactions = {}
    idx = 0
    while True:
        line = f.readline()
        if not line:
            break;
        a = line.strip().split()
        if len(a) < 3:
            continue
        del a[0]
        i = 0
        b = []
        for obj in a:
            if len(chr) <= 4:
                if obj[:5] == chr + ':':
                    b.append(str(int(obj[5:]) // re))  # 取100k为分辨率
                    i += 1
            else:
                if obj[:6] == chr + ':':
                    b.append(str(int(obj[6:]) // re))  # 取100k为分辨率
                    i += 1
        b = list(set(b))
        if not b or len(b) < 2:
            continue
        if len(b) >= 1000: continue
        Multiple_interactions[idx] = b
        idx += 1
    f.close()
    return Multiple_interactions

def hypergraph_build(Multiple_interactions):
        Multiple_interactions_hypergraph = hnx.Hypergraph(Multiple_interactions)
        print('Multiple_interactions_hypergraph done!')
        return Multiple_interactions_hypergraph

def mkdir(file_dir, file):
    # filelist = os.path.
    if not os.path.exists(file_dir + '\\' + file):
        os.makedirs(file_dir + '\\' + file)

def savetxt(file_dir, file, output, chr_key, raw = False):
    h_dir = file_dir
    H_dir = file_dir + '\\' + file
    if raw:
        name = 'raw_' + chr_key
    else:
        name = file + '_' + chr_key
    mkdir(h_dir, file)
    mkdir(H_dir, chr_key)
    print('savetxt the features now')
    np.savetxt(H_dir + '\\' + chr_key + '\\' + name + '.txt', output, fmt='%.3f', delimiter=" ")
    return

def get_sigmoid_value(output):
    a = torch.tensor(output)
    return torch.sigmoid(a)

def savejpg(file_dir, file, output, chr_key, raw = False, re = 100000):
    h_dir = file_dir
    H_dir = file_dir + '\\' + file
    if raw:
        name = 'raw_' + chr_key
    else:
        name = file + '_' + chr_key
    mkdir(h_dir, file)
    mkdir(H_dir, chr_key)
    print('savejpg the features now')
    plt.figure(dpi=120)
    sns.heatmap(output, cmap='cubehelix', vmin=0, vmax=1, cbar=False)
    plt.xlabel(str(re) + '_' + name)
    plt.ylabel('bins')
    plt.savefig(H_dir + '\\' + chr_key + '\\' + name + '.jpg')
    plt.close()

def get_raw(chr, chr_key, re, Multiple_interactions):
    raw_output = np.zeros((chr[chr_key] // re + 1, chr[chr_key] // re + 1))
    for edge in Multiple_interactions.keys():
        if len(Multiple_interactions[edge]) >= 1000: continue
        for bin1, bin2 in combinations(Multiple_interactions[edge], 2):
            raw_output[int(bin1)][int(bin2)] += 1
            raw_output[int(bin2)][int(bin1)] += 1
    return raw_output

if __name__ == '__main__':
    main()