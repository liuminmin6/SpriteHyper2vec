import argparse


def args_parser():
    parser = argparse.ArgumentParser()
    parser.add_argument('--p', type=float, default=0.5, help='return parameter')
    parser.add_argument('--q', type=float, default=0.25, help='in-out parameter')
    parser.add_argument('--d', type=int, default=32, help='dimension')
    parser.add_argument('--r', type=int, default=5, help='walks per node')
    parser.add_argument('--l', type=int, default=9, help='walk length')
    parser.add_argument('--k', type=float, default=4, help='window size')
    parser.add_argument('--re', type=int, default=100000, help='resolution')
    args = parser.parse_args()
    return args
