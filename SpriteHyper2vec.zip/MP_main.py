import hypernetx as hnx
from args import args_parser
from node2vec import node2vec
import os
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from itertools import combinations
import time
import multiprocessing
import eventlet
from scc2 import get_scc2


def get_file_name(file_dir):
    L = []
    for root, dirs, files in os.walk(file_dir):
        for file in files:
            L.append(file)
    return L


def node2vec_MP(chr_key, chr, file_dir, re, file, start, stop):
    # if chr_key in done: return
    args = args_parser()
    scSCRIPE_dir = file_dir + '\\filtered_1000_cells_single_cell_files'
    HiC_node2vec_dir = file_dir + '\\HiC_node2vec'
    starttime = time.time()
    Multiple_interactions = get_Multiple_interactions(chr_key, scSCRIPE_dir, file, re, chr, start, stop)
    raw_output = get_raw(chr, re, Multiple_interactions)
    savetxt(HiC_node2vec_dir, file, raw_output, chr_key, re, start, stop, raw=True)
    # savejpg(HiC_node2vec_dir, file, raw_output, chr_key, re, raw=True)
    if np.all(raw_output == 0):
        output = raw_output
        savetxt(HiC_node2vec_dir, file, output, chr_key, re, start, stop)
        # savejpg(HiC_node2vec_dir, file, output, chr_key, re)
    else:
        Multiple_interactions_hypergraph = hypergraph_build(Multiple_interactions)
        G = Multiple_interactions_hypergraph
        vec = node2vec(args, G, chr, file, chr_key)
        output = vec.learning_features()
        savetxt(HiC_node2vec_dir, file, output, chr_key, re, start, stop, raw=False)
        # savejpg(HiC_node2vec_dir, file, output, chr_key, re)
    endtime = time.time()
    costtime = endtime - starttime
    fig_on(output, raw_output, file, re)
    print(file + '_' + chr_key + '_' + 'costtime = ' + str(costtime))
    return


def raw_add_all(chr_key, file_dir, chr, re=100000):
    scSCRIPE_dir = file_dir + '\\filtered_1000_cells_single_cell_files'
    files = get_file_name(scSCRIPE_dir)
    output_raw = np.zeros((chr // re + 1, chr // re + 1))
    name = 'raw_all' + '_' + str(re)
    print('get raw_add_all now!')
    for file in files:
        print(file)
        name_raw = 'raw_' + chr_key + '_' + str(re)
        raw_dir = file_dir + '\\HiC_node2vec\\' + file + '\\' + chr_key + '\\' + name_raw + '.matrix.gz'
        Multiple_interactions = get_Multiple_interactions(chr_key, scSCRIPE_dir, file, re, chr)
        raw_output = get_raw(chr, re, Multiple_interactions)
        output_raw += raw_output
    np.savetxt(name + '.matrix.gz', output_raw, fmt='%.3f', delimiter=" ")
    return output_raw


'''def cell_add(chr_key, file_dir, chr, re=100000):
    scSCRIPE_dir = file_dir + '\\filtered_1000_cells_single_cell_files'
    output = np.zeros((chr // re + 1, chr // re + 1))
    output_raw = np.zeros((chr // re + 1, chr // re + 1))
    raw_all = np.loadtxt('raw_all'+'_'+str(re)+'.txt')
    f2 = open('re_file.txt', 'r', encoding='utf-8')
    f1 = open('p_' + str(re) + '.txt', 'w', encoding='utf-8')
    i = 0
    while True:
        i+=1
        file = f2.readline().strip('\n')
        if not file: break
        if not Result_record(file_dir, chr_key, file, re): continue
        name = file + '_' + chr_key + '_' + str(re)
        name_raw = 'raw_' + chr_key + '_' + str(re)
        node_dir = file_dir + '\\HiC_node2vec\\' + file + '\\' + chr_key + '\\' + name + '.txt'
        raw_dir = file_dir + '\\HiC_node2vec\\' + file + '\\' + chr_key + '\\' + name_raw   + '.txt'
        #Multiple_interactions = get_Multiple_interactions(chr_key, scSCRIPE_dir, file, re, chr)
        print(i)
        #raw_output = get_raw(chr, re, Multiple_interactions)
        raw_output = np.loadtxt(raw_dir)
        output_raw += raw_output
        o = np.loadtxt(node_dir)
        if o.shape != output.shape:continue
        output += o
        a1, a2 = get_scc2(raw_output, raw_all, chr // re + 1)
        b1, b2 = get_scc2(o, raw_all, chr // re + 1)
        q = str(a1) + ' ' + str(b1) + ' ' + file
        f1.write(q)
        f1.write('\n')
        print(q)
    a1, a2 = get_scc2(output_raw, raw_all, chr // re + 1)
    b1, b2 = get_scc2(output, raw_all, chr // re + 1)
    q = str(a1) + ' ' + str(b1)
    f1.write(q)
    f1.write('\n')
    f1.close()
    f2.close()
    return
'''

def log(file, chr_key, file_dir):
    H_dir = file_dir + '\\' + file
    #name = file + '_' + chr_key
    Timeout = 'Timeout error'
    f = open(H_dir + '\\' + chr_key + '\\' + 'timeout.txt', 'a', encoding='utf-8')
    f.write(Timeout)
    f.close()
    return print(Timeout)


def loginfo(file, chr, file_dir):
    HiC_node2vec_dir = file_dir + '\\HiC_node2vec'
    f_info = open(HiC_node2vec_dir + '\\' + 'loginfo.txt', 'a', encoding='utf-8')
    f_info.write(file + ' ' + chr + '\n')
    f_info.close()
    return


def loginfo_MP(map_all, file):
    return loginfo(file, map_all[1], map_all[3])


def node2vec_MP_invalue(map_all):
    return node2vec_MP(map_all[0], map_all[1], map_all[2], map_all[3], map_all[4])


def get_all_map(file_dir, re):
    # 获取所有染色体长度
    # scSCRIPE_dir = file_dir + '\\filtered_1000_cells_single_cell_files'
    # files = get_file_name(scSCRIPE_dir)
    # np.random.shuffle(files)
    #f_chr = open(file_dir + '\\' + 'mm9.txt')
    chr = []
    f1 = open('re_file.txt', 'r', encoding='utf-8')
    #while True:
        #line = f_chr.readline()
        #if not line:
            #break
    while True:
        file = f1.readline().strip('\n')
        if not file:
            break
        # a = line.strip().split()
        if not Result_record(file_dir, 'chr4', file, re): chr.append((file, 'chr4', 155630120, file_dir, re))
        # chr.append((file, a[0], int(a[1])//2, file_dir, re))
    f1.close()
    #f_chr.close()
    print('未完成的chr条目数：', len(chr))
    #raw_add_all('chr1', file_dir, chr, re)
    return chr


def Result_record(file_dir, chr_key, file, re=100000):
    HiC_node2vec_dir = file_dir + '\\HiC_node2vec'
    chr_dir = HiC_node2vec_dir + '\\' + file + '\\' + chr_key + '\\' + file + '_' + chr_key + '_' + str(re) + '.matrix.gz'
    if os.path.isfile(chr_dir):
        f = open(chr_dir, 'r', encoding='utf-8')
        read_data = f.readline()
        f.close()
        if read_data == 'Timeout error':
            return False
        else: return True
    return False


def get_chr(file_dir):
    # 获取所有染色体长度
    f_chr = open(file_dir + '\\' + 'mm9.txt')
    chr = {}
    while True:
        line = f_chr.readline()
        if not line:
            break;
        a = line.strip().split()
        chr[a[0]] = int(a[1])
    f_chr.close()
    return chr


def get_Multiple_interactions(chr_key, scSCRIPE_dir, file, re, chr, start, stop):
    f = open(scSCRIPE_dir + '\\' + file, 'r', encoding='utf-8')
    Multiple_interactions = {}
    idx = 0
    while True:
        line = f.readline()
        if not line:
            break;
        a = line.strip().split()
        if len(a) < 3:
            continue
        del a[0]
        i = 0
        b = []
        for obj in a:
            if len(chr_key) <= 4:
                if obj[:5] == chr_key + ':' and int(obj[5:]) <= chr:
                    if start <= int(obj[5:]) <= stop:
                        b.append(str(int(obj[5:]) // re))  # 取100k为分辨率
                        i += 1
            else:
                if obj[:6] == chr_key + ':' and int(obj[6:]) <= chr:
                    if start <= int(obj[6:]) <= stop:
                        b.append(str(int(obj[6:]) // re))  # 取100k为分辨率
                        i += 1
        b = list(set(b))
        if not b or len(b) < 2:
            continue
        if len(b) >= 1000: continue
        Multiple_interactions[idx] = b
        idx += 1
    f.close()
    return Multiple_interactions


def hypergraph_build(Multiple_interactions):
    Multiple_interactions_hypergraph = hnx.Hypergraph(Multiple_interactions)
    print('Multiple_interactions_hypergraph done!')
    return Multiple_interactions_hypergraph


def mkdir(file_dir, file):
    # filelist = os.path.
    if not os.path.exists(file_dir + '\\' + file):
        os.makedirs(file_dir + '\\' + file)


def savetxt(file_dir, file, output, chr_key, re, start, stop, raw=False):
    h_dir = file_dir
    H_dir = file_dir + '\\' + file
    if raw:
        name = 'raw_' + chr_key + '_' + str(re) + '_' + str(start)
    else:
        name = file + '_' + chr_key + '_' + str(re) + '_' + str(start)
    mkdir(h_dir, file)
    mkdir(H_dir, chr_key)
    print('savetxt the features now', 'name: ', file, name)
    np.savetxt(H_dir + '\\' + chr_key + '\\' + name + '.matrix.gz', output[start:stop, start:stop], fmt='%.3f', delimiter=" ")
    return


def add_savejpg(file_dir, num, round, chr_key, output, re=100000):
    h_dir = file_dir + '\\add_cell'
    H_dir = file_dir + '\\add_cell' + '\\' + str(num)
    save_dir = file_dir + '\\add_cell' + '\\' + str(num) + '\\' + chr_key
    mkdir(h_dir, str(num))
    mkdir(H_dir, chr_key)
    mkdir(save_dir, str(round))
    print('savejpg the features now')
    plt.figure(dpi=120)
    sns.heatmap(output, cmap='cubehelix', vmin=0, vmax=num, cbar=False)
    plt.xlabel(str(re) + '_' + str(round))
    plt.ylabel('bins')
    plt.savefig(save_dir + '\\' + str(round) + '.jpg')
    plt.close()


def savejpg(file_dir, file, output, chr_key, re=100000, raw=False):
    h_dir = file_dir
    H_dir = file_dir + '\\' + file
    if raw:
        name = 'raw_' + chr_key + '_' + str(re)
    else:
        name = file + '_' + chr_key + '_' + str(re)
    mkdir(h_dir, file)
    mkdir(H_dir, chr_key)
    print('savejpg the features now, name: ', file, name)
    plt.figure(dpi=120)
    sns.heatmap(output, cmap='cubehelix', vmin=0, vmax=1, cbar=False)
    plt.xlabel(str(re) + '_' + name)
    plt.ylabel('bins')
    plt.savefig(H_dir + '\\' + chr_key + '\\' + name + '.jpg')
    plt.close()


def randomfile(file_dir, r):
    scSCRIPE_dir = file_dir + '\\filtered_1000_cells_single_cell_files'
    files = get_file_name(scSCRIPE_dir)
    #np.random.shuffle(files)
    i = 0
    if r >= len(files): r = len(files)
    with open('re_file.txt', 'w', encoding='utf-8') as f:
        for file in files:
            if i >= r: break
            f.write(file + '\n')
            i += 1
    return


def fig(file_dir, file, chr_key, re=100000):
    if Result_record(file_dir, chr_key, file, re):
        name = file + '_' + chr_key + '_' + str(re)
        o_dir = file_dir + '\\HiC_node2vec\\' + file + '\\' + chr_key + '\\' + name + '.matrix.gz'
        raw_dir = file_dir + '\\HiC_node2vec\\' + file + '\\' + chr_key + '\\' + 'raw_chr1' + '_' + str(re) + '.matrix.gz'
        data = np.loadtxt(o_dir)
        data1 = np.loadtxt(raw_dir)
        plt.figure(dpi=120)
        data = np.tril(data1, k=0) + np.triu(data, k=0)
        sns.set(font_scale=1.5)
        plt.rc('font', family='Times New Roman', size=12)
        sns.heatmap(data, cmap='hot', vmin=0, vmax=1, cbar=False, center=1)
        plt.xlabel(str(re) + '_' + name)
        plt.ylabel('raw')
        print('save fig now!', file)
        plt.savefig(file_dir + '\\HiC_node2vec\\' + file + '\\' + chr_key + '\\' + '2.jpg')
        plt.close()


def fig_on(output, raw_output, file, re=100000):
    H_dir = file_dir + '\\' + file + '\\chr4'
    data = output
    data1 = raw_output
    plt.figure(dpi=120)
    data = np.tril(data1, k=0) + np.triu(data, k=0)
    sns.set(font_scale=1.5)
    plt.rc('font', family='Times New Roman', size=12)
    sns.heatmap(data, cmap='hot', vmin=0, vmax=1, cbar=False, center=1)
    plt.xlabel(str(re) + '_' + file)
    plt.ylabel('raw')
    print('save fig now!', file)
    plt.savefig(H_dir + '\\' + '2.jpg')
    plt.close()


def get_raw(chr, re, Multiple_interactions):
    raw_output = np.zeros((chr // re + 1, chr // re + 1))
    for edge in Multiple_interactions.keys():
        if len(Multiple_interactions[edge]) >= 1000: continue
        for bin1, bin2 in combinations(Multiple_interactions[edge], 2):
            raw_output[int(bin1)][int(bin2)] += 1
            raw_output[int(bin2)][int(bin1)] += 1
    return raw_output

def add_cell(start, stop, file):
    file_dir = 'D:\\dataset'
    #H_dir = file_dir + '\\' + file + '\\chr4'
    re = args_parser().re
    node2vec_MP('chr4', 155630120, file_dir, re, file, start, stop)
    '''raw_output = np.loadtxt(H_dir + '\\' + 'raw_' + 'chr4' + '_' + str(re) + '_' + str(start) + '.txt')
    output = np.loadtxt(H_dir + '\\' + file + '_' + 'chr4' + '_' + str(re) + '_' + str(start) + '.txt')
    raw_all = np.loadtxt('raw_all_20000.txt')
    raw_all = raw_all[start:stop,start:stop]
    print('save fig now!', start, stop)
    fig_on(output, raw_output, num, 'chr1', re, i, start)
    fig_on(raw_all, raw_output, num, 'chr1', re, i, start, raw_all=True)
    a1, a2 = get_scc2(raw_output, raw_all, 500)
    b1, b2 = get_scc2(output, raw_all, 500)
    log_scc(start, stop, a1, b1, re, i)
    print(str(a1) + ' ' + str(b1) + ' ' + str(i) + '\n', start, stop)'''
    return

def log_scc(start, stop, a, b, re, i):
    with open('scc_log.txt', 'a', encoding='utf-8') as f:
        f.write(str(i) + ' ' + str(a) + ' ' + str(b) + ' ' + str(re) + ' ' + str(start) + ' ' + str(stop))
        f.write('\n')
    return


def add_cell_invalue(a):
    return add_cell(a[0], a[1], a[2])

if __name__ == '__main__':
    file_dir = 'D:\\dataset'
    scSCRIPE_dir = file_dir + '\\filtered_1000_cells_single_cell_files'
    files = get_file_name(scSCRIPE_dir)
    HiC_node2vec_dir = file_dir + '\\HiC_node2vec'
    a = get_all_map()


    p = multiprocessing.Pool(12)
    re = args_parser().re
    a = []
    for file in files:
        a.append((124800000, 126700000, file))
    #map_all = get_all_map(file_dir, re)
    p.map_async(add_cell_invalue, a)
    p.close()
    p.join()
    '''file_dir = 'D:\\dataset'
    HiC_node2vec_dir = file_dir + '\\HiC_node2vec'
    re = args_parser().re'''
    #cell_add('chr1', file_dir, 197195432, re)