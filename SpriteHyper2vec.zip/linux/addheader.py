import os
os.sys.path.append(os.path.join( os.path.dirname(__file__), '..'))
import pandas as pd
import numpy as np
from add_cell import get_mat, get_mat_chr1
from hicorrector import main
from scipy.stats import zscore
from sklearn import preprocessing
def get_insulation(in_dir, re, chr, num, i):
    #file_dir = 'mnt/d/dataset/HiCnode2vec/'
    #file_dir = '/'.join(file_dir, file, chr)
    #filename = '_'.join(file, str(re)) + '.matrix.gz'
    #outname = '_'.join(file, str(re), 'tocsv') + '.txt'
    mat = np.loadtxt(in_dir)
    mat = mat[100:1000, 100:1000]
    colnames = ['|'.join(['bin'+str(m),'mm9' ,chr+':'+str(int(m*re))+'-'+str(int(m*re+re))]) for m in range(len(mat))]
    cell_pd = pd.DataFrame(mat)
    cell_pd.columns = colnames
    cell_pd.index = colnames
    csv_file = '/mnt/d/dataset/insulation/' + '_'.join([str(num), str(re), str(i)]) + '.txt'
    cell_pd.to_csv(csv_file,sep='\t')
    pl_code='/mnt/d/py_project/cword/cworld-dekker-master/scripts/perl/matrix2insulation.pl'
    #inputfile = 'mnt/d/dataset/HiCnode2vec/insulation/' + '_'.join(str(num), str(re)), str(i)
    outputfile = '/mnt/d/dataset/insulation/' + '_'.join(['insulation', str(num), str(re), str(i)])
    command = ' '.join(['perl', pl_code, '-i', csv_file, '--ss', '80000', '--im', 'mean',
                       '--is', '480000', '--ids', '320000', '-o', outputfile, '--nt', '0.15'])

    print('getting insulation for ', '_'.join([str(num), str(re), str(i)]))
    os.system(command)

def get_heatmap(num, re, i):
    in_dir = '/mnt/d/dataset/insulation/' + '_'.join([str(num), str(re), str(i)]) + '.txt'
    pl_code = '/mnt/d/py_project/cword/cworld-dekker-master/scripts/perl/heatmap.pl'
    outfile = '/mnt/d/dataset/heatmap/' + '_'.join(['heatmap', str(num), str(re), str(i)])
    command = ' '.join(['perl', pl_code, '-i', in_dir, '-o', outfile])
    print('getting heatmap for ', in_dir)
    os.system(command)


def zscore_norm(matrix):
    v = matrix.reshape((-1))
    if not (v == v[0]).all():
        matrix = zscore(v).reshape((len(matrix), -1))
    return matrix


def get_input(mat_dir, out_dir):
    node = np.loadtxt(mat_dir)
    node = zscore_norm(node)
    np.savetxt(out_dir, node, delimiter="\t", fmt="%1f")


def get_compartment(in_dir, re, chr, num, i):
    mat = np.loadtxt(in_dir)
    mat = mat[30:, 30:]

    colnames = ['|'.join(['bin' + str(m), 'mm9', chr + ':' + str(int(m * re)) + '-' + str(int(m * re + re))]) for m in
                range(len(mat))]
    cell_pd = pd.DataFrame(mat)
    '''values = cell_pd.values
    values = values.astype('float32')
    data = preprocessing.scale(values)
    cell_pd = pd.DataFrame(data)'''
    cell_pd.columns = colnames
    cell_pd.index = colnames
    csv_file = '/mnt/d/dataset/compartment/' + '_'.join([str(num), str(re), str(i)]) + '.txt'
    cell_pd.to_csv(csv_file, sep='\t')
    pl_code = '/mnt/d/py_project/cword/cworld-dekker-master/scripts/perl/matrix2compartment.pl'
    py_code = '/mnt/d/py_project/cword/cworld-dekker-master/scripts/python/matrix2EigenVectors.py'
    # inputfile = 'mnt/d/dataset/HiCnode2vec/insulation/' + '_'.join(str(num), str(re)), str(i)
    outputfile = '/mnt/d/dataset/compartment/' + '_'.join(['compartment', str(num), str(re), str(i)])
    #command = ' '.join(['perl', pl_code, '-i', csv_file, '-o', outputfile])
    command_cp = ' '.join(['perl', pl_code,  '-i', csv_file])
    print('getting cp for ', '_'.join([str(num), str(re), str(i)]))
    os.system(command_cp)

    '''pl_code = '/mnt/d/py_project/cword/cworld-dekker-master/scripts/perl/heatmap.pl'
    outfile = '/mnt/d/dataset/heatmap/' + '_'.join(['heatmap', str(num), str(re), str(i)])
    command = ' '.join(['perl', pl_code, '-i', csv_file, '-o', outfile])
    print('getting heatmap for ', csv_file)
    os.system(command)
'''
def n(num, re, i):
    mat_dir, raw_dir = get_mat('chr4', num, re, '.npz', '/mnt/d/py_project/HiC_node2vec/data')
    main(mat_dir, '/mnt/d/py_project/HiC_node2vec/data/norm_out.matrix')
    main(raw_dir, '/mnt/d/py_project/HiC_node2vec/data/norm_raw.matrix')
    get_insulation(in_dir='/mnt/d/py_project/HiC_node2vec/notebooks/dsProject/norm_raw_all_chr4_40000.matrix', re=re,
                   chr='chr4', num=num, i='all' + str(i) + str(num))
    get_insulation(in_dir='/mnt/d/py_project/HiC_node2vec/data/norm_out.matrix', re=re,
                   chr='chr4', num=num, i='node' + str(i) + str(num))
    get_insulation(in_dir='/mnt/d/py_project/HiC_node2vec/data/norm_raw.matrix', re=re,
                   chr='chr4', num=num, i='raw' + str(i) + str(num))

def cp(num, re, i):
    #mat_dir, raw_dir = get_mat_chr1('chr1', num, re, '.npz', '/mnt/d/py_project/HiC_node2vec/data')
    #main(mat_dir, '/mnt/d/py_project/HiC_node2vec/data/norm_out.matrix')
    #main(raw_dir, '/mnt/d/py_project/HiC_node2vec/data/norm_raw.matrix')
    get_compartment(in_dir='/mnt/d/py_project/HiC_node2vec/sprite/raw_all_100000.matrix', re=re,
                   chr='chr1', num=num, i='node' + str(i) + str(num))
    main('/mnt/d/py_project/HiC_node2vec/sprite/raw_all_100000.matrix', '/mnt/d/py_project/HiC_node2vec/sprite/norm_raw_all_100000.matrix')
    get_compartment(in_dir='/mnt/d/py_project/HiC_node2vec/sprite/norm_raw_all_100000.matrix', re=re,
                    chr='chr1', num=num, i='normnode' + str(i) + str(num))
    '''get_compartment(in_dir=mat_dir, re=re,
                   chr='chr1', num=num, i='node' + str(i) + str(num))
                   
    get_compartment(in_dir=mat_dir, re=re,
                   chr='chr1', num=num, i='raw' + str(i) + str(num))'''

if __name__ == "__main__":
    for i in range(9, 10):
        for num in [100, 200, 500]:
            print(i, num)
            cp(num=num, re=100000, i=i)
            break
    '''get_insulation(in_dir='/mnt/d/py_project/HiC_node2vec/notebooks/dsProject/norm_raw_all_chr4_40000.matrix', re=40000,
                   chr='chr4', num=50, i='all' + str(0) + str(50))'''