import numpy as np
import subprocess
import os
import scipy
from scipy.sparse import csr_matrix
import warnings
'''from scipy.stats import pearsonr, PearsonRConstantInputWarning
def get_scc2(mat1, mat2, max_bins):
    """
    Compute the stratum-adjusted correlation coefficient (SCC) between two
    Hi-C matrices up to max_dist. A Pearson correlation coefficient is computed
    for each diagonal in the range of 0 to max_dist and a weighted sum of those
    coefficients is returned.
    Parameters
    ----------
    mat1 : scipy.sparse.csr_matrix
        First matrix to compare.
    mat2 : scipy.sparse.csr_matrix
        Second matrix to compare.
    max_bins : int
        Maximum distance at which to consider, in bins.
    Returns
    -------
    scc : float
        Stratum adjusted correlation coefficient.
    """

    if max_bins < 0 or max_bins > int(mat1.shape[0] - 5):
        max_bins = int(mat1.shape[0] - 5)

    mat1 = csr_matrix(mat1)
    mat2 = csr_matrix(mat2)
    corr_diag = np.zeros(len(range(max_bins)))
    weight_diag = corr_diag.copy()
    for d in range(max_bins):
        d1 = mat1.diagonal(d)
        d2 = mat2.diagonal(d)
        mask = (~np.isnan(d1)) & (~np.isnan(d2))
        d1 = d1[mask]
        d2 = d2[mask]
        # Silence NaN warnings: this happens for empty diagonals and will
        # not be used in the end.
        with warnings.catch_warnings():
            warnings.filterwarnings(
                "ignore", category=PearsonRConstantInputWarning
            )
            # Compute raw pearson coeff for this diag
            # corr_diag[d] = ss.pearsonr(d1, d2)[0]
            cor = pearsonr(d1, d2)[0]
            corr_diag[d] = cor
        # corr_diag[d] = spearmanr(d1, d2)[0]
        # Compute weight for this diag
        r2k = vstrans(d1, d2)
        weight_diag[d] = len(d1) * r2k
    corr_diag, weight_diag = corr_diag[1:], weight_diag[1:]
    mask = ~np.isnan(corr_diag)
    corr_diag, weight_diag = corr_diag[mask], weight_diag[mask]
    # Normalize weights
    weight_diag /= sum(weight_diag)
    # Weighted sum of coefficients to get SCCs
    scc = np.nansum(corr_diag * weight_diag)
    return scc, max_bins - np.sum(mask)
'''

def vstrans(d1, d2):
    """
    Variance stabilizing transformation to normalize read counts before computing
    stratum correlation. This normalizes counts so that different strata share similar
    dynamic ranges.
    Parameters
    ----------
    d1 : numpy.array of floats
        Diagonal of the first matrix.
    d2 : numpy.array of floats
        Diagonal of the second matrix.
    Returns
    -------
    r2k : numpy.array of floats
        Array of weights to use to normalize counts.
    """
    # Get ranks of counts in diagonal
    ranks_1 = np.argsort(d1) + 1
    ranks_2 = np.argsort(d2) + 1
    # Scale ranks betweeen 0 and 1
    nranks_1 = ranks_1 / max(ranks_1)
    nranks_2 = ranks_2 / max(ranks_2)
    nk = len(ranks_1)
    r2k = np.sqrt(np.var(nranks_1 / nk) * np.var(nranks_2 / nk))
    return r2k

def main(input_file, output_file):
    contacts = np.loadtxt(input_file)
    contacts = ice_raw_contacts(contacts, input_file, 'bias_file_raw_all_100000.txt', 100, '/mnt/d/py_project/HiC_node2vec/HiCorrector/bin/ic')
    contacts = truncate_to_median_diagonal_value(contacts)
    write_contacts_to_file(contacts, outfile=output_file, fmt = "%1f")
    return contacts

def ice_raw_contacts(contacts, raw_contacts_file, bias_file, iterations, hicorrector_path):
    biases = calculate_bias_factors(contacts=contacts, raw_contacts_file=raw_contacts_file, bias_file=bias_file, hicorrector=hicorrector_path, iterations=iterations)
    median_diagonal_value = get_median_diagonal_value(contacts)
    for row in range(contacts.shape[0]):
        for col in range(contacts.shape[1]):
            val = contacts[row][col]
            if val > 0:
                val /= (biases[row] * biases[col])
                contacts[row][col] = val
    return contacts


def calculate_bias_factors(contacts, raw_contacts_file, bias_file, hicorrector, iterations):
    skip_first_row = "0"    # 0 == don't skip
    skip_first_column = "0"
    num_lines = contacts.shape[0]
    subprocess.check_call([hicorrector, raw_contacts_file, str(num_lines), str(iterations), skip_first_row, skip_first_column, bias_file])
    return parse_bias_file(bias_file)


def parse_bias_file(bias_file):
    biases = []
    with open(bias_file) as f:
        for line in f:
            biases.append(float(line.strip()))
    return biases


def get_median_diagonal_value(contacts):


    diagonal_values = []

    for i in range(contacts.shape[0] - 1):
        diagonal_values.append(contacts[i + 1][i])
        diagonal_values.append(contacts[i][i + 1])

    return np.median(diagonal_values)


def write_contacts_to_file(contacts, outfile, fmt):
    np.savetxt(outfile, contacts, delimiter = "\t", fmt = fmt)


def truncate_to_median_diagonal_value(contacts):

    median_diagonal_value = get_median_diagonal_value(contacts)
    for row in range(contacts.shape[0]):
        for col in range(contacts.shape[1]):
            val = contacts[row][col]
            val = (1 if val >= median_diagonal_value
                    else val / median_diagonal_value)
            contacts[row][col] = val
    return contacts

def get_file_name(file_dir):
    L = []
    for root, dirs, files in os.walk(file_dir):
        for file in files:
            L.append(file)
    return L


def randomfile(file_dir, r):
    scSCRIPE_dir = file_dir + '\\filtered_1000_cells_single_cell_files'
    files = get_file_name(scSCRIPE_dir)
    #np.random.shuffle(files)
    if r >= len(files): r = len(files)
    return files[:r]


def get_rawandout(file, file_dir, chr_key, re, type):
    o_dir = file_dir + '\\' + file + '\\' + chr_key + '\\' + file + '_' + chr_key + type
    r_dir = file_dir + '\\' + file + '\\' + chr_key + '\\' + 'raw_' + chr_key + type
    if type == '.matrix.gz':
        raw = np.loadtxt(r_dir)
        node = np.loadtxt(o_dir)
        return raw, node
    elif type == '.npz':
        raw = scipy.sparse.load_npz(r_dir)
        node = scipy.sparse.load_npz(o_dir)
        return raw, node


'''def pearson_score(m1, m2):
    return pearsonr(m1.reshape((-1)), m2.reshape((-1)))[0]
'''

if __name__ == "__main__":
    '''node = main('/mnt/d/py_project/HiC_node2vec/notebooks/dsProject/node_chr4_100000.matrix')
    raw = main('/mnt/d/py_project/HiC_node2vec/notebooks/dsProject/raw_chr4_100000.matrix')
    mat1 = np.loadtxt('/mnt/d/py_project/HiC_node2vec/notebooks/dsProject/norm_bulk_all_chr4_100000.matrix')
    all = main('raw_all_chr4_100000.matrix')'''

    '''pearson_score_rawwithhic = pearson_score(raw, mat1)
    pearson_score_nodewithhic = pearson_score(node, mat1)
    pearson_score_allwithhic = pearson_score(mat1, all)
    print(pearson_score_allwithhic, pearson_score_nodewithhic, pearson_score_rawwithhic)
    a1, a2 = get_scc2(mat1, all, 155630120//100000)
    b1, b2 = get_scc2(node, mat1, 155630120//100000)
    c1, c2 = get_scc2(raw, mat1, 155630120//100000)
    print(a1, b1, c1)'''


    contact = main('/mnt/d/py_project/HiC_node2vec/data/raw_all_chr4_40000.matrix', '/mnt/d/py_project/HiC_node2vec/notebooks/dsProject/norm_raw_all_chr4_40000.matrix')