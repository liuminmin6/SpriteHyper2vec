import numpy as np
import csv
import os
from os import path
def scaner_file(url):
    file = os.listdir(url)
    for f in file:
        if f == 'chr4' : continue
        real_url = path.join(url, f)
        if path.isfile(real_url) and f[-4:] == '.txt':
            print(path.abspath(real_url))
            a = np.loadtxt(path.abspath(real_url))
            np.savetxt(url + '\\' + f[:-4] + '.matrix.gz', a, delimiter = "\t", fmt = "%.2f")
            os.remove(real_url)
            # 如果是文件，则以绝度路径的方式输出
        elif path.isdir(real_url):
            # 如果是目录，则是地柜调研自定义函数 scaner_file (url)进行多次
            scaner_file(real_url)
        else:
            print("其他情况, 无有效内容")
            pass
        print(real_url)



#scaner_file("D:\\dataset\\HiC_node2vec")
'''a = np.loadtxt('D:\\dataset\\HiC_node2vec\\DPM6bot1.Odd2Bo1.Even2Bo61\\chr1\\.txt.matrix.gz')
b = a  + a'''
def get_file_name(file_dir):
    L = []
    for root, dirs, files in os.walk(file_dir):
        for file in files:
            L.append(file)
    return L

def transfer(x, f):
    raw = np.loadtxt(x + '\\' + f)
    np.savetxt(x + '\\' + f[:-4] + '.matrix.gz', raw, delimiter="\t", fmt="%.2f")
    del raw
    print(x + '\\' + f, 'done!')
    os.remove(x + '\\' + f)
    return

def transfer_in(a):
    return transfer(a[0], a[1])


import multiprocessing
if __name__ == '__main__':
    file_dir = 'D:\\dataset'
    scSCRIPE_dir = file_dir + '\\filtered_1000_cells_single_cell_files'
    files = get_file_name(scSCRIPE_dir)
    a = []
    for file in files:
        x = file_dir + '\\HiC_node2vec\\' + file + '\\chr1'
        x_file = get_file_name(x)
        for f in x_file:
            if f[-4:] == '.txt': a.append((x, f))
    print(len(a))
    p = multiprocessing.Pool(10)
    p.map_async(transfer_in, a)
    p.close()
    p.join()

