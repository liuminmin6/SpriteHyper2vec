import os
import pandas as pd
import numpy as np
from tqdm import tqdm
from scipy import sparse
def make_file(mat, re, output_dir, output_name):
    mat = mat.todense()
    pos1, pos2 = mat.nonzero()
    columns = ['str1', 'chr1', 'x1', 'frag1', 'str2', 'chr2', 'x2', 'frag2', 'score']
    index = [i for i in range(len(pos2))]
    #index = [i for i in range(100)]
    d = []
    for i in tqdm(range(len(pos2))):
        d.append([0, 'chr1', pos1[i] * re, 0, 1, 'chr1', pos2[i] * re, 1, mat[pos1[i], pos2[i]]])
    data = pd.DataFrame(d, columns=columns, index=index)
    data.to_csv(output_dir + '\\' + output_name + '.hic.input',index = False, header = None, sep = "\t")

if __name__ == '__main__':
    mat = sparse.load_npz('D:\\py_project\\HiC_node2vec\\data\\node_200_chr4_10000.npz')
    re = 10000
    output_dir = 'D:\\py_project\\HiC_node2vec\\data'
    output_name = 'chrnode10000'
    make_file(mat, re, output_dir, output_name)
    print('done')
    