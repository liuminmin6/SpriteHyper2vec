import numpy as np
import csv
import os
from os import path
from scipy.sparse import coo_matrix
import scipy
import time
def scaner_file(url):
    file = os.listdir(url)
    for f in file:
        if f == 'chr4' : continue
        real_url = path.join(url, f)
        if path.isfile(real_url) and f[-15:] == '10000.matrix.gz':
            print(path.abspath(real_url))
            a = np.loadtxt(path.abspath(real_url))
            np.savetxt(url + '\\' + f[:-4] + '.matrix.gz', a, delimiter = "\t", fmt = "%.2f")
            os.remove(real_url)
            # 如果是文件，则以绝度路径的方式输出
        elif path.isdir(real_url):
            # 如果是目录，则是地柜调研自定义函数 scaner_file (url)进行多次
            scaner_file(real_url)
        else:
            print("其他情况, 无有效内容")
            pass
        print(real_url)



#scaner_file("D:\\dataset\\HiC_node2vec")
'''a = np.loadtxt('D:\\dataset\\HiC_node2vec\\DPM6bot1.Odd2Bo1.Even2Bo61\\chr1\\.txt.matrix.gz')
b = a  + a'''
def get_file_name(file_dir):
    L = []
    for root, dirs, files in os.walk(file_dir):
        for file in files:
            L.append(file)
    return L

def transfer(x, f):
    raw = np.loadtxt(x + '\\' + f)
    raw = np.array(raw)
    c = coo_matrix(raw)
    scipy.sparse.save_npz(x + '\\' + f[:-10] + '.npz', c)
    #np.savetxt(x + '\\' + f[:-4] + '.matrix.gz', raw, delimiter="\t", fmt="%.2f")
    del raw
    print(x + '\\' + f, 'done!')
    #os.remove(x + '\\' + f)
    #t(x, f)
    return

def transfer_in(a):
    return transfer(a[0], a[1])

def t(x, f):
    print(4)
    t1 = time.time()
    raw = np.loadtxt(x + '\\' + f)
    t2 = time.time()
    print(t2 - t1)
    c = scipy.sparse.load_npz(x + '\\' + f[:-10] + '.npz')
    c = c.todense()
    t3 = time.time()
    print(t3 - t2)
def Result_record(file_dir, chr_key, file, re=100000):
    HiC_node2vec_dir = file_dir + '\\HiC_node2vec'
    chr_dir = HiC_node2vec_dir + '\\' + file + '\\' + chr_key + '\\' + file + '_' + chr_key + '_' + str(re) + '.npz'
    a_dir = HiC_node2vec_dir + '\\' + file + '\\' + chr_key + '\\' + 'raw_' + chr_key + '_' + str(re) + '.npz'
    if os.path.isfile(chr_dir) and os.path.isfile(a_dir):
        return True
    return False

import multiprocessing
if __name__ == '__main__':
    file_dir = 'D:\\dataset'
    scSCRIPE_dir = file_dir + '\\filtered_1000_cells_single_cell_files'
    files = get_file_name(scSCRIPE_dir)
    a = []
    for file in files:
        x = file_dir + '\\HiC_node2vec\\' + file + '\\chr1'

        x_file = get_file_name(x)
        for f in x_file:
            if f[-15:] == '40000.matrix.gz' and not Result_record(file_dir, 'chr1', file, 40000): a.append((x, f))

    print(len(a))
    p = multiprocessing.Pool(8)
    p.map_async(transfer_in, a)
    p.close()
    p.join()


    '''file = 'raw_all_chr4_40000.matrix'
    all = np.loadtxt(file + '.gz')
    np.savetxt(file, all, delimiter = "\t", fmt = "%1f")
'''



    #t('D:\\py_project\\HiC_node2vec', 'raw_all_10000.matrix.gz')