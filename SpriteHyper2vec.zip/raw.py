from args import args_parser
import numpy as np
from itertools import combinations
def main():
    f = open('D:\\dataset\\filtered_1000_cells_single_cell_files\\DPM6bot1.Odd2Bo1.Even2Bo61', 'r', encoding='utf-8')
    Multiple_interactions = {}
    idx = 0
    while True:
        line = f.readline()
        if not line:
            break;
        a = line.strip().split()
        if len(a) < 3:
            continue
        del a[0]
        i = 0
        b = []
        for obj in a:
            if obj[:5] == args_parser().chr + ':':
                b.append(str(int(obj[5:]) // args_parser().re))  # 取100k为分辨率
                i += 1
        b = list(set(b))
        if not b or len(b) < 2:
            continue

        Multiple_interactions[idx] = b
        idx += 1
    f.close()
    raw = np.zeros((159599783// args_parser().re + 1,159599783// args_parser().re + 1))
    for edge in Multiple_interactions.keys():
        if len(Multiple_interactions[edge]) >= 1000: continue
        for bin1, bin2 in combinations(Multiple_interactions[edge], 2):
            raw[int(bin1)][int(bin2)] += 1
            raw[int(bin2)][int(bin1)] += 1
    np.savetxt("D:\\py_project\\HiC_node2vec\\raw.txt", raw, fmt='%1f', delimiter=" ")
if __name__ == '__main__':
    main()