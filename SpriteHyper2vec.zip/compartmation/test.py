import os
import numpy as np
import pandas as pd
import higashi
from tqdm import tqdm
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib as mpl
from scipy.interpolate import make_interp_spline
import matplotlib.gridspec as gridspec
from scipy.stats import pearsonr
def get_file_name(file_dir):
    L = []
    for root, dirs, files in os.walk(file_dir):
        for file in files:
            L.append(file)
    return L


def randomfile(file_dir, r):
    scSCRIPE_dir = file_dir + '\\filtered_1000_cells_single_cell_files'
    files = get_file_name(scSCRIPE_dir)
    np.random.shuffle(files)
    return files[:r]


def scadd(files, israw=True):
    file_dir = 'D:\\dataset'
    HiC_node2vec_dir = file_dir + '\\HiC_node2vec'
    r = np.zeros((197195432 // 100000 + 1, 197195432 // 100000 + 1))
    for file in tqdm(files):
        if israw:
            name = 'raw' + '_chr1.matrix.gz'
        else:
            name = str(file) + '_chr1.matrix.gz'
        if os.path.exists(HiC_node2vec_dir + '\\' + file + '\\' + 'chr1' + '\\' + str(file) + '_chr1.matrix.gz'):
            out = np.loadtxt(HiC_node2vec_dir + '\\' + file + '\\' + 'chr1' + '\\' + name)
            print(name)
            r += out
    return r

def sc_add_t3(files, israw=True):
    file_dir = 'D:\\dataset'
    HiC_node2vec_dir = file_dir + '\\HiC_node2vec'
    r = np.zeros((520, 520))
    for file in files:
        if israw:
            name = 'raw' + '_chr2.txt'
        else:
            name = str(file) + '_chr2.txt'
        if os.path.exists(HiC_node2vec_dir + '\\' + file + '\\' + 'chr2' + '\\' + str(file) + '_chr2.txt'):
            out = np.loadtxt(HiC_node2vec_dir + '\\' + file + '\\' + 'chr2' + '\\' + name)
        print(name)
        r += out[30:550, 30:550]
    return r



def fig_on(output, raw_output, num, chr_key, re, i):
    H_dir = 'D:\\dataset\\add_cell' + '\\' + str(num) + '\\' + chr_key
    data = output
    data1 = raw_output
    plt.figure(dpi=400)
    data = np.tril(data1, k=0) + np.triu(data, k=0)
    sns.set(font_scale=1.5)
    plt.rc('font', family='Times New Roman', size=12)
    sns.heatmap(data, cmap='hot', vmin=-2, vmax=2, cbar=True, center=0)
    plt.xlabel(str(re) + '_' + str(num))
    plt.ylabel('raw')
    print('save fig now!', num)
    plt.savefig(H_dir + '\\' + 'node_' + str(re) + '_' + str(i) + '.jpg')
    plt.close()


def fig_chr_heatmap(out_matrix, raw_out_matrix, num, chr_key, re, i, start, stop):
    H_dir = 'D:\\dataset\\add_cell' + '\\' + str(num) + '\\' + chr_key
    raw_all = np.loadtxt('./raw_all.txt')
    raw_all = raw_all[start:stop, start:stop]
    c_o_all, m_o_all = higashi.compartment(raw_all, return_PCA=True)
    out_pc1 = higashi.compartment(out_matrix, False, m_o_all, None)
    raw_out_pc1 = higashi.compartment(raw_out_matrix, False, m_o_all, None)
    data = out_pc1
    data1 = raw_out_pc1
    plt.figure(figsize=(15, 6))
    widths = [5, 5, 5]
    heights = [5, 1]
    r = 5
    gs = gridspec.GridSpec(nrows=2, ncols=3, width_ratios=widths,height_ratios=heights)
    for k in range(3):
        if k == 0:
            ax = plt.subplot(gs[0, k])
            im = ax.matshow(out_matrix, cmap='YlOrRd', vmin=-1.5, vmax=2)
            ax.set_title('out', fontdict={'fontsize': 20, 'fontweight': 'medium'})
            ax.set_xticklabels([])
            ax.set_yticklabels([])
            ax = plt.subplot(gs[1, k])
            columns = ['E1']
            data = data * r
            data = pd.DataFrame(data, columns=columns)
            data['positive'] = data['E1'] > 0
            data['E1'].plot(kind='bar', color=data.positive.map({True: 'r', False: 'b'}))
            ax.set_xticklabels([])
            ax.set_ylim(-1.2, 1.2)
            print(1)
        if k == 1:
            ax = plt.subplot(gs[0, k])
            im = ax.matshow(raw_out_matrix, cmap='YlOrRd', vmin=-1.5, vmax=2)
            ax.set_title('raw', fontdict={'fontsize': 20, 'fontweight': 'medium'})
            ax.set_xticklabels([])
            ax.set_yticklabels([])
            ax = plt.subplot(gs[1, k])
            columns = ['E1']
            data1 = data1* r
            data = pd.DataFrame(data1, columns=columns)
            data['positive'] = data['E1'] > 0
            data['E1'].plot(kind='bar', color=data.positive.map({True: 'r', False: 'b'}))
            ax.set_xticklabels([])
            ax.set_ylim(-1.2, 1.2)
            print(2)
        if k == 2:
            a = higashi.compartment(raw_all, False)
            all = higashi.zscore_norm(raw_all)
            ax = plt.subplot(gs[0, k])
            im = ax.matshow(all, cmap='YlOrRd', vmin=-1.5, vmax=2)
            ax.set_title('all', fontdict={'fontsize': 20, 'fontweight': 'medium'})
            ax.set_xticklabels([])
            ax.set_yticklabels([])
            ax = plt.subplot(gs[1, k])
            columns = ['E1']
            a = a * r
            data = pd.DataFrame(a, columns=columns)
            #print(data)
            data['positive'] = data['E1'] > 0
            data['E1'].plot(kind='bar', color=data.positive.map({True: 'r', False: 'b'}))
            ax.set_xticklabels([])
            ax.set_ylim(-1.2, 1.2)
            print(3)
    plt.savefig('152.jpg')


def fig_50cell():
    files = randomfile('D:\\dataset', 50)
    r = scadd(files, True)
    o = scadd(files, False)
    raw_all = np.loadtxt('./raw_all.txt')
    a1, a2 = higashi.get_scc2(r, raw_all, 197195432 // 100000 + 1)
    b1, b2 = higashi.get_scc2(o, raw_all, 197195432 // 100000 + 1)
    print(str(a1) + ' ' + str(b1))
    r = higashi.zscore_norm(r)
    o = higashi.zscore_norm(o)
    fig_on(o, r, 50, 'chr1', 100000, 2)

def c_1(files, i, isall=False):
    file_dir = 'D:\\dataset'
    # HiC_node2vec_dir = file_dir + '\\HiC_node2vec'
    # files = randomfile(file_dir, r)

    if isall:
        raw_all = np.loadtxt('./raw_all.txt')
        raw_all = raw_all[1250:1750, 1250:1750]
        c_o_all = higashi.compartment(raw_all)
        compartment_np(c_o_all, 'all')
    else:
        raw_all = np.loadtxt('./raw_all.txt')
        raw_all = raw_all[600:1100, 600:1100]
        c_o_all, m_o_all = higashi.compartment(raw_all, return_PCA=True)
        o = scadd(files, False)
        o = o[600:1100, 600:1100]
        c_o = higashi.compartment(o, False, m_o_all, None)
        compartment_np(c_o, i, 'model')
        r = scadd(files, True)
        r = r[600:1100, 600:1100]
        c_r = higashi.compartment(r, False, m_o_all, None)
        compartment_np(c_r, i, 'raw')


def compartment(files, i, isall=False):
    file_dir = 'D:\\dataset'
    #HiC_node2vec_dir = file_dir + '\\HiC_node2vec'
    #files = randomfile(file_dir, r)

    if isall:
        raw_all = np.loadtxt('./raw_all.txt')
        raw_all = raw_all[600:1100, 600:1100]
        c_o_all = higashi.compartment(raw_all)
        compartment_np(c_o_all, i, 'all')
    else:

        o = scadd(files, False)
        o = o[600:1100, 600:1100]
        c_o = higashi.compartment(o, False)
        compartment_np(c_o, i, 'model')
        r = scadd(files, True)
        r = r[600:1100, 600:1100]
        c_r = higashi.compartment(r, False)
        compartment_np(c_r, i, 'raw')
    '''for file in tqdm(files):
        if os.path.exists(HiC_node2vec_dir + '\\' + file + '\\' + 'chr1' + '\\' + str(file) + '_chr1.matrix.gz'):
            print(file)
            raw_output = np.loadtxt(HiC_node2vec_dir + '\\' + file + '\\' + 'chr1' + '\\' + 'raw' + '_chr1.matrix.gz')
            output = np.loadtxt(HiC_node2vec_dir + '\\' + file + '\\' + 'chr1' + '\\' + str(file) + '_chr1.matrix.gz')
            c_o = higashi.compartment(output, False, m_o_all, None)
            c_r = higashi.compartment(raw_output, False, m_o_all, None)
            compartment_raw.append(c_r)
            compartment_out.append(c_o)
    compartment_raw = np.array(compartment_raw)
    compartment_out = np.array(compartment_out)
    np.save('compartment_raw.npy', compartment_raw)
    np.save('compartment_out.npy', compartment_out)
'''


def compartment_fig(compartment_data, file_name):
    plt.figure(dpi=200)
    data = compartment_data
    sns.set(font_scale=1.5)
    plt.rc('font', family='Times New Roman', size=5)
    sns.heatmap(data, cmap='RdYlGn_r', vmin=-4, vmax=4, cbar=False, center=0)
    plt.xlabel('compartment_data')
    plt.ylabel(file_name)
    plt.savefig(file_name)
    plt.close()

def compartment_np(compartment_data, j,title):
    plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']

    l = len(compartment_data)
    bin = []
    for i in range(l):
        '''if compartment_data[i] > 5:
            compartment_data[i] = 5'''
        bin.append(i)
    x_smooth = np.linspace(0, 500, 100)
    y1_smooth = make_interp_spline(bin, compartment_data)(x_smooth)
    plt.plot(x_smooth, y1_smooth, linestyle='-',
             linewidth=1, color='steelblue',
            markersize=6,
             markeredgecolor='black',
             markerfacecolor='brown')

    plt.ylabel('PC1')
    plt.title(title)
    ax = plt.gca()
    plt.xticks(rotation=45)
    #plt.show()
    plt.savefig('D:\\dataset\\c_fig\\' + title + str(j) + '.jpg')
    plt.close()
def pearson_score(m1, m2):
    return pearsonr(m1.reshape((-1)), m2.reshape((-1)))[0]


def sam2mat():
    file_dir = 'D:\\dataset'
    HiC_node2vec_dir = file_dir + '\\HiC_node2vec'
    start = 950
    stop = 1350
    files = randomfile(file_dir, 50)
    out_matrix = scadd(files, israw=False)
    raw_out_matrix = scadd(files, israw=True)
    out_matrix = out_matrix[start:stop, start:stop]
    raw_out_matrix = raw_out_matrix[start:stop, start:stop]
    out_matrix = higashi.zscore_norm(out_matrix)
    raw_out_matrix = higashi.zscore_norm(raw_out_matrix)
    # fig_chr_heatmap(out_matrix, raw_out_matrix, 50, 'chr1', 10000, 1, start, stop)
    raw_all = np.loadtxt('D:\\py_project\\HiC_node2vec\\raw_all_chr1_100000.matrix')
    raw_all = raw_all[start:stop, start:stop]
    raw_all = higashi.zscore_norm(raw_all)
    c_o_all, m_o_all = higashi.compartment(raw_all, return_PCA=True)
    out_pc1 = higashi.compartment(out_matrix, False)
    raw_out_pc1 = higashi.compartment(raw_out_matrix, False)

    s1 = pearson_score(out_pc1, c_o_all)
    s2 = pearson_score(raw_out_pc1, c_o_all)
    print(s1, s2)
    return s1, s2

if __name__ == '__main__':
    '''compartment()
    compartment_raw = np.load('compartment_raw.npy').tolist()
    compartment_out = np.load('compartment_out.npy').tolist()

    raw_output = np.zeros((996, 1972))
    output = np.zeros((996, 1972))
    score = np.zeros(996)
    score1 = np.zeros(996)
    for i in range(996):
        for j in range(1971):
            raw_output[i][j] = round(compartment_raw[i][j][0], 1)
            output[i][j] = round(compartment_out[i][j][0], 1)
            if j <= 800:
                score[i] += output[i][j]
                score1[i] += raw_output[i][j]
    #output = np.around(output, 2)
    #score = np.around(score, 2)
    for i in range(996):
        output[i][-1] = score[i]
        raw_output[i][-1] = score[i]
    #output = sorted(output, key=lambda x:x[-1])
    #raw_output = sorted(raw_output, key=lambda x: x[-1])
    compartment_fig(raw_output[:-1],'compartment_raw.jpg')
    compartment_fig(output[:-1],'compartment_out.jpg')'''
    '''file_dir = 'D:\\dataset'
    for i in range(20):
        files = randomfile(file_dir, 50)
        compartment(files, i, False)
        c_1(files, i+100, False)
    file_dir = 'D:\\dataset'
    files = randomfile(file_dir, 50)
    compartment(files, 77, True)'''
    #fig_50cell()
    '''file_dir = 'D:\\dataset'
    HiC_node2vec_dir = file_dir + '\\HiC_node2vec'
    files = get_file_name(file_dir)
    f = []
    i = 0
    for file in files:
        #if i >= 50: break
        if os.path.exists(HiC_node2vec_dir + '\\' + file + '\\' + 'chr2' + '\\' + str(file) + '_chr2.jpg'):
            f.append(file)
            i += 1
    np.random.shuffle(f)
    f1 = f[0:-1]
    r = sc_add_t3(f1, israw=True)
    o = sc_add_t3(f1, israw=True)
    r = higashi.zscore_norm(r)
    o = higashi.zscore_norm(o)
    fig_on(o, r, 50, 'chr2', 100000, 215)'''
    '''file_dir = 'D:\\dataset'
    HiC_node2vec_dir = file_dir + '\\HiC_node2vec'
    start = 950
    stop = 1350
    files = randomfile(file_dir, 50)
    out_matrix = scadd(files, israw=False)
    raw_out_matrix = scadd(files, israw=True)
    out_matrix = out_matrix[start:stop, start:stop]
    raw_out_matrix = raw_out_matrix[start:stop, start:stop]
    out_matrix = higashi.zscore_norm(out_matrix)
    raw_out_matrix = higashi.zscore_norm(raw_out_matrix)
    fig_chr_heatmap(out_matrix, raw_out_matrix, 50, 'chr1', 10000, 1, start, stop)'''

    for i in range(5):
        s1, s2 = sam2mat()
