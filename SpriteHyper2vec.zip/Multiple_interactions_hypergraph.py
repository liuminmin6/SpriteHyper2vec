class hypergraph:
    def __init__(self, Multiple_interactions):
        self.g_dict = Multiple_interactions


    def incidence_dict(self, dict):
        return dict

    def dual(self):
        g_duality = {}
        for edge in self.edges():
            for node in self.g_dict[edge]:
                if node in g_duality.keys():
                    g_duality[node].union({edge})
                else:
                    g_duality[node] = {edge}
        self.g_duality = g_duality
        self.nodes = list(self.g_duality.keys())
        return self.g_duality

    def edges(self):
        self.edges = list(self.g_dict.keys())
        return list(self.g_dict.keys())

    def nodes(self):
        return list(self.g_duality.keys())

    def degree(self, n):
        return len(self.g_duality[n])
