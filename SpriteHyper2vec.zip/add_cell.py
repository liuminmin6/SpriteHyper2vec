import numpy as np
import scipy
from scipy import sparse
from tqdm import tqdm
import os
def get_file_name(file_dir):
    L = []
    for root, dirs, files in os.walk(file_dir):
        for file in files:
            L.append(file)
    return L
def randomfile(file_dir, r):
    scSCRIPE_dir = file_dir + '/filtered_1000_cells_single_cell_files'
    files = get_file_name(scSCRIPE_dir)
    np.random.shuffle(files)
    if r >= len(files): r = len(files)
    return files[:r]
def get_rawandout(file, file_dir, chr_key, re, type, ifnew=False):
    #100kb
    if not ifnew:
        o_dir = file_dir + '/' + file + '/' + chr_key + '/' + file + '_' + chr_key + '_' + str(re) + type
        r_dir = file_dir + '/' + file + '/' + chr_key + '/' + 'raw_' + chr_key + '_' + str(re) + type
    else:
        o_dir = file_dir + '/' + file + '/' + chr_key + '/' + file + '_' + chr_key + '_' + str(re) + '_new' + type
        r_dir = file_dir + '/' + file + '/' + chr_key + '/' + 'raw_' + chr_key + '_' + str(re) + '_new' + type

    #print(o_dir)
    if type == '.matrix.gz':
        raw = np.loadtxt(r_dir)
        node = np.loadtxt(o_dir)
        return raw, node
    elif type == '.npz':
        raw = scipy.sparse.load_npz(r_dir)
        node = scipy.sparse.load_npz(o_dir)
        return raw, node
    return #print('error : get none mat')
def Result_record(file_dir, chr_key, file, re=100000):
    chr_dir = file_dir + '/' + file + '/' + chr_key + '/' + file + '_' + chr_key + '.txt'
    if os.path.isfile(chr_dir):
        return True
    return False
def get_mat(chr, num, re, type, output_dir):
    '''

    :param chr:
    :param num:
    :param re:
    :param type:.npz'
    :param output_dir:
    :return:
    '''
    file_dir = '/mnt/d/dataset'
    files = randomfile(file_dir, num)
    HiC_dir = file_dir + '/HiC_node2vec'
    chr_key = chr
    raw, node = get_rawandout(files[0], HiC_dir, chr_key, re, type)
    for file in tqdm(files[1:]):
        r, n = get_rawandout(file, HiC_dir, chr_key, re, type)
        if node.shape == n.shape:
            raw = raw + r
            node = node + n
    if type == '.npz':
        raw = raw.todense()
        node = node.todense()
    np.savetxt('/'.join([output_dir, 'node_' + chr + '_' + str(re) + '.matrix']), node, delimiter = "\t", fmt = "%1f")
    np.savetxt('/'.join([output_dir, 'raw_' + chr + '_' + str(re) + '.matrix']), raw, delimiter = "\t", fmt = "%1f")
    return '/'.join([output_dir, 'node_' + chr + '_' + str(re) + '.matrix']), '/'.join([output_dir, 'raw_' + chr + '_' + str(re) + '.matrix'])

def get_all(chr, num, re, type, output_dir):
    file_dir = '/mnt/d/dataset'
    files = randomfile(file_dir, num)
    HiC_dir = file_dir + '/HiC_node2vec'
    chr_key = chr
    raw, node = get_rawandout(files[0], HiC_dir, chr_key, re, type)
    for file in tqdm(files[1:]):
        r, n = get_rawandout(file, HiC_dir, chr_key, re, type)
        if node.shape == n.shape:
            raw = raw + r
            node = node + n
    sparse.save_npz('/'.join([output_dir, 'raw_' + str(num) + '_' + chr + '_' + str(re) + '.npz']), raw)
    sparse.save_npz('/'.join([output_dir, 'node_' + str(num) + '_' + chr + '_' + str(re) + '.npz']), node)
    #raw = raw.todense()
    #np.savetxt('/'.join([output_dir, 'raw_' + chr + '_' + str(re) + '.matrix']), raw, delimiter="\t", fmt="%1f")
    print('done')
    return



def Result_record_chr1(file_dir, chr_key, file):
    chr_dir = file_dir + '/' + file + '/' + chr_key + '/' + file + '_' + chr_key + '.npz'
    if os.path.isfile(chr_dir):
        return True
    return False

def get_rawandout_chr1(file, file_dir, chr_key, re, type):
    #100kb
    o_dir = file_dir + '/' + file + '/' + chr_key + '/' + file + '_' + chr_key + type
    r_dir = file_dir + '/' + file + '/' + chr_key + '/' + 'raw_' + chr_key + type
    #print(o_dir)
    if type == '.matrix.gz':
        raw = np.loadtxt(r_dir)
        node = np.loadtxt(o_dir)
        return raw, node
    elif type == '.npz':
        raw = scipy.sparse.load_npz(r_dir)
        node = scipy.sparse.load_npz(o_dir)
        return raw, node
    return #print('error : get none mat')
def get_mat_chr1(chr, num, re, type, output_dir):
    '''
    :param chr:
    :param num:
    :param re:
    :param type:.npz'
    :param output_dir:
    :return:
    '''
    file_dir = '/mnt/d/dataset'
    files = randomfile(file_dir, num)

    #print(files)
    HiC_dir = file_dir + '/lym/HiC_node2vec'
    chr_key = chr
    if Result_record_chr1(HiC_dir, chr_key, files[0]):
        raw, node = get_rawandout_chr1(files[0], HiC_dir, chr_key, re, type)
    for file in tqdm(files[1:]):
        if Result_record_chr1(HiC_dir, chr_key, file):
            r, n = get_rawandout_chr1(file, HiC_dir, chr_key, re, type)
        if node.shape == n.shape:
            raw = raw + r
            node = node + n
    if type == '.npz':
        raw = raw.todense()
        node = node.todense()
    np.savetxt('/'.join([output_dir, 'node_' + chr + '_' + str(re) + '.matrix']), node, delimiter="\t", fmt="%1f")
    np.savetxt('/'.join([output_dir, 'raw_' + chr + '_' + str(re) + '.matrix']), raw, delimiter="\t", fmt="%1f")
    return '/'.join([output_dir, 'node_' + chr + '_' + str(re) + '.matrix']), '/'.join(
        [output_dir, 'raw_' + chr + '_' + str(re) + '.matrix'])

    #return raw, node


if __name__ == '__main__':
    get_all('chr4', 200, 10000, '.npz', '/mnt/d/py_project/HiC_node2vec/data')