import hypernetx as hnx
from args import args_parser
from node2vec import node2vec
import os
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from itertools import combinations
import time
import multiprocessing
import eventlet
from scc2 import get_scc2
from Multiple_interactions_hypergraph import hypergraph
import pandas as pd

def get_file_name(file_dir):
    L = []
    for root, dirs, files in os.walk(file_dir):
        for file in files:
            L.append(file)
    return L


def node2vec_MP_MC(chr_key, chr, file_dir, re, num, i, files, start, stop):
    # if chr_key in done: return
    args = args_parser()
    scSCRIPE_dir = file_dir + '\\filtered_1000_cells_single_cell_files'
    starttime = time.time()
    Multiple_interactions = get_Multiple_interactions_MC(chr_key, scSCRIPE_dir, files, re, chr, start, stop)
    raw_output = get_raw(chr, re, Multiple_interactions)
    savetxt_MC(file_dir, files, raw_output, chr_key, re, num, i, start, stop, raw=True)
    # savejpg(HiC_node2vec_dir, file, raw_output, chr_key, re, raw=True)
    if np.all(raw_output == 0):
        output = raw_output
        savetxt_MC(file_dir, files, output, chr_key, re, num, i)
        # savejpg(HiC_node2vec_dir, file, output, chr_key, re)
    else:
        Multiple_interactions_hypergraph = hypergraph_build(Multiple_interactions)
        #Multiple_interactions_hypergraph = hypergraph(Multiple_interactions)
        vec = node2vec(args, Multiple_interactions_hypergraph, chr, files[0], chr_key)
        output = vec.learning_features()
        savetxt_MC(file_dir, files, output, chr_key, re, num, i, start, stop)
        # savejpg(HiC_node2vec_dir, file, output, chr_key, re)
    endtime = time.time()
    costtime = endtime - starttime
    print(str(num) + '_' + chr_key + '_' + 'costtime = ' + str(costtime))
    return costtime


def get_Multiple_interactions_MC(chr_key, scSCRIPE_dir, files, re, chr, start, stop):
    Multiple_interactions = {}
    idx = 0
    for file in files:
        f = open(scSCRIPE_dir + '\\' + file, 'r', encoding='utf-8')
        while True:
            line = f.readline()
            if not line:
                break;
            a = line.strip().split()
            if len(a) < 3:
                continue
            del a[0]
            i = 0
            b = []
            for obj in a:
                if len(chr_key) <= 4:
                    if obj[:5] == chr_key + ':' and int(obj[5:]) <= chr:
                        if start <= int(obj[5:]) // re <= stop:
                            b.append(str(int(obj[5:]) // re))  # 取100k为分辨率
                            i += 1
                else:
                    if obj[:6] == chr_key + ':' and int(obj[6:]) <= chr:
                        if start <= int(obj[6:]) // re <= stop:
                            b.append(str(int(obj[6:]) // re))  # 取100k为分辨率
                            i += 1
            b = list(set(b))
            if not b or len(b) < 2:
                continue
            if len(b) >= 1000: continue
            Multiple_interactions[idx] = b
            idx += 1
        f.close()
    return Multiple_interactions


def hypergraph_build(Multiple_interactions):
    Multiple_interactions_hypergraph = hnx.Hypergraph(Multiple_interactions)
    return Multiple_interactions_hypergraph


def mkdir(file_dir, file):
    # filelist = os.path.
    if not os.path.exists(file_dir + '\\' + file):
        os.makedirs(file_dir + '\\' + file)


def savetxt_MC(file_dir, files, output, chr_key, re, num, i, start, stop, raw=False):
    if raw:
        name = 'raw_' + str(re) + '_' + str(i)
    else:
        name = 'node_' + str(re) + '_' + str(i)
    H_dir = file_dir + '\\add_cell'
    mkdir(H_dir, str(num))
    mkdir(H_dir + '\\' + str(num), chr_key)
    if not raw:print('savetxt the features now', 'num: ', num, start, stop, i)
    np.savetxt(H_dir + '\\' + str(num) + '\\' + chr_key + '\\' + name + '.txt', output[start:stop, start:stop], fmt='%.3f', delimiter=" ", encoding='utf-8')
    with open(H_dir + '\\' + str(num) + '\\' + chr_key + '\\' + 're_file_' + str(i) + '.txt', 'w', encoding='utf-8') as f:
        for file in files:
            f.write(file + '\n')
    return


def randomfile(file_dir, r):
    scSCRIPE_dir = file_dir + '\\filtered_1000_cells_single_cell_files'
    files = get_file_name(scSCRIPE_dir)
    np.random.shuffle(files)
    if r >= len(files): r = len(files)
    return files[:r]


def fig_on(output, raw_output, num, chr_key, re, i, start, raw_all=False):
    file_dir = 'D:\\dataset'
    H_dir = file_dir + '\\add_cell' + '\\' + str(num) + '\\' + chr_key
    mkdir(file_dir + '\\add_cell', str(num))
    mkdir(file_dir + '\\add_cell' + '\\' + str(num), chr_key)
    data = output
    data1 = raw_output
    plt.figure(dpi=120)
    data = np.tril(data1, k=0) + np.triu(data, k=0)
    sns.set(font_scale=1.5)
    plt.rc('font', family='Times New Roman', size=12)
    #sns.heatmap(data, cmap='hot', vmin=0, vmax=5, cbar=False, center=1)
    sns.heatmap(data, cmap='hot', vmin=0, vmax=1000, cbar=False)

    plt.xlabel(str(re) + '_' + str(num))
    plt.ylabel('raw')

    if not raw_all:
        plt.savefig(H_dir + '\\' + 'node_' + str(re) + '_' + str(i) + str(start) + '.jpg')
    else:
        plt.savefig(H_dir + '\\' + 'node_' + str(re) + '_' + str(i) + str(start) +'_rwa_all' + '.jpg')
    plt.close()


def get_raw(chr, re, Multiple_interactions):
    raw_output = np.zeros((chr // re + 1, chr // re + 1))
    for edge in Multiple_interactions.keys():
        if len(Multiple_interactions[edge]) >= 100: continue
        for bin1, bin2 in combinations(Multiple_interactions[edge], 2):
            raw_output[int(bin1)][int(bin2)] += 1
            raw_output[int(bin2)][int(bin1)] += 1
    return raw_output


def add_cell(i, start, stop, files):
    num = 400000
    file_dir = 'D:\\dataset'
    H_dir = file_dir + '\\add_cell' + '\\' + str(num) + '\\' + 'chr4'
    re = args_parser().re
    #files = randomfile(file_dir, num)
    node2vec_MP_MC('chr4', 155630120, file_dir, re, num, i, files, start, stop)
    raw_output = np.loadtxt(H_dir + '\\' + 'raw_' + str(re) + '_' + str(i) + '.txt')
    output = np.loadtxt(H_dir + '\\' + 'node_' + str(re) + '_' + str(i) + '.txt')
    raw_all = np.loadtxt('raw_all_40000.txt')
    raw_all = raw_all[start:stop,start:stop]
    print('save fig now!', start, stop)
    fig_on(output, raw_output, num, 'chr1', re, i, start)
    fig_on(raw_all, raw_output, num, 'chr1', re, i, start, raw_all=True)
    a1, a2 = get_scc2(raw_output, raw_all, 500)
    b1, b2 = get_scc2(output, raw_all, 500)
    log_scc(start, stop, a1, b1, re, i)
    print(str(a1) + ' ' + str(b1) + ' ' + str(i) + '\n', start, stop)
    return



def add_node2vec(i, start, stop):
    num = 15
    file_dir = 'D:\\dataset'
    re = args_parser().re
    output = np.zeros((197195432 // re + 1, 197195432 // re + 1))
    files = randomfile(file_dir, 20)
    for file in files:
        name = file + '_chr1_20000'
        o = np.loadtxt('D:\\dataset\\HiC_node2vec\\' + file + '\\chr1\\' + name + '.txt')
        output += o
    raw_all = np.loadtxt('raw_all_20000.txt')
    output = output[start:stop, start:stop]
    raw_all = raw_all[start:stop, start:stop]
    print('save fig now!', start, stop)
    fig_on(output, raw_all, num, 'chr1', re, i)
    b1, b2 = get_scc2(output, raw_all, 197195432 // re + 1)
    log_scc(start, stop, 1, b1, re, i)
    print(' ' + str(b1) + ' ' + str(i) + '\n', start, stop)
    return


def add_cell_invalue(a):
    return add_cell(a[0], a[1], a[2], a[3])


def log_scc(start, stop, a, b, re, i):
    with open('scc_log.txt', 'a', encoding='utf-8') as f:
        f.write(str(i) + ' ' + str(a) + ' ' + str(b) + ' ' + str(re) + ' ' + str(start) + ' ' + str(stop))
        f.write('\n')
    return


def normalize_along_diagonal_from_numpy(d, chrom, max_bin_distance, output_filename, binsize, remove_bins, trim = 0.01):
    #df_all = pd.DataFrame()
    if os.path.exists(output_filename):
        os.remove(output_filename)
    with open(output_filename, "a") as f:
        for offset in range(1, max_bin_distance + 1):
            r, c = get_nth_diag_indices(d, offset)
            vals_orig = d[r,c].tolist()

            if isinstance(vals_orig[0], list):
                vals_orig = vals_orig[0]
            if offset == 1:
                print("here", output_filename)
                #print(type(vals_orig))
                #print(type(vals_orig[0]))
                print(len(vals_orig))
                print(vals_orig[:20])
            #vals_orig = vals_orig[0]

            vals = vals_orig.copy()
            vals.sort()
            vals.reverse()
            trim_value = vals[(round(trim * len(vals)) - 1)]
            trim_index = round(trim * len(vals)) - 1
            remaining = vals[(trim_index):]
            mu = np.mean(remaining)
            sd = np.std(remaining)
            #print(vals_orig[:5])
            #print('musd')
            #print(mu, sd)
            #vals_orig = vals_orig[0][:]
            vals_orig = (np.array(vals_orig) - mu) / sd
            if sd < 1e-6:
                vals_orig = [0] * len(vals_orig)
                #print(len(vals_orig))
            #print(offset,mu,sd,max(vals_orig))
            #print(vals_orig[:5])
            #print(r.shape, c.shape, vals_orig.shape)
            df = pd.DataFrame({'x1': r, 'y1': c, 'v': vals_orig})
            df['x1'] = ((df['x1'] + remove_bins) * binsize).astype(int)
            df['y1'] = ((df['y1'] + remove_bins) * binsize).astype(int)
            df['x2'] = (df['x1'] + binsize).astype(int)
            df['y2'] = (df['y1'] + binsize).astype(int)
            df['chr1'] = chrom
            df['chr2'] = chrom
            df = df[['chr1', 'x1', 'x2', 'chr2', 'y1', 'y2', 'v']]
            df.to_csv(f, mode='a', header=False, sep = "\t", index = False)

def get_nth_diag_indices(mat, offset):
    rows, cols_orig = np.diag_indices_from(mat)
    cols = cols_orig.copy()
    if offset > 0:
        cols += offset
        rows = rows[:-offset]
        cols = cols[:-offset]
    return rows, cols

if __name__ == '__main__':
    a = []
    '''for i in range(0,20):
        files = randomfile('D:\\dataset', 5)
        a.append((i, 124800000//40000, 126700000//40000, files))
    for i in range(0,20):
        files = randomfile('D:\\dataset', 10)
        a.append((i, 124800000//40000, 126700000//40000, files))
    for i in range(0,20):
        files = randomfile('D:\\dataset', 20)
        a.append((i, 124800000//40000, 126700000//40000, files))'''
    for i in range(0,20):
        files = randomfile('D:\\dataset', 50)
        a.append((i, 124800000//40000, 126700000//40000, files))
    p = multiprocessing.Pool(8)
    p.map_async(add_cell_invalue, a)
    p.close()
    p.join()
#normalize_along_diagonal_from_numpy(rwa_all)