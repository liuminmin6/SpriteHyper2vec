import hypernetx as hnx
from gensim.models import word2vec
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
def main():
    f = open('D:\\dataset\\filtered_1000_cells_single_cell_files\\DPM6bot1.Odd2Bo1.Even2Bo61', 'r', encoding='utf-8')
    Multiple_interactions = {}
    idx = 0
    while True:
        line = f.readline()
        if not line:
            break;
        a = line.strip().split()
        if len(a) < 3:
            continue
        del a[0]
        i = 0
        b = []
        for obj in a:
            if obj[:5] == 'chr3:':
                b.append(str(int(obj[5:]) // 100000))  # 取40k为分辨率
                i += 1
        b = list(set(b))
        if not b or len(b) < 2:
            continue
        if len(b) >= 1000:continue
        Multiple_interactions[idx] = b
        idx += 1
    f.close()
    Multiple_interactions_hypergraph = hnx.Hypergraph(Multiple_interactions)
    model = word2vec.Word2Vec.load("word2vec.model")
    bin_i = 0
    output = np.zeros((159599783//100000+1,159599783//100000+1))

    print('111')
    while bin_i <= 159599783 // 100000:
        bin_j = 0
        while bin_j <= 159599783 // 100000:
            if str(bin_i) in Multiple_interactions_hypergraph.nodes and str(bin_j) in Multiple_interactions_hypergraph.nodes:
                if model.wv.similarity(str(bin_i), str(bin_j)) > 0.7:
                    output[bin_i][bin_j] = '%.3f' % model.wv.similarity(str(bin_i), str(bin_j))
                else:
                    output[bin_i][bin_j] = '%.3f' % 0
            bin_j += 1
        bin_i += 1
    np.savetxt("D:\py_project\HiC_node2vec\ouput.txt", output, fmt='%.3f', delimiter=" ")
    return output
def heatmap(output):
    sns.heatmap(output, annot=False)
    plt.savefig('output.jpg')

if __name__ == "__main__":
    output = main()
    heatmap(output)
