from scipy.sparse import csr_matrix
import warnings
from scipy.stats import pearsonr, PearsonRConstantInputWarning
import numpy as np
import matplotlib.pyplot as plt
from pylab import *
rcParams['axes.unicode_minus'] = False
rcParams['font.sans-serif'] = ['Simhei']
def get_scc2(mat1, mat2, max_bins):
    """
    Compute the stratum-adjusted correlation coefficient (SCC) between two
    Hi-C matrices up to max_dist. A Pearson correlation coefficient is computed
    for each diagonal in the range of 0 to max_dist and a weighted sum of those
    coefficients is returned.
    Parameters
    ----------
    mat1 : scipy.sparse.csr_matrix
        First matrix to compare.
    mat2 : scipy.sparse.csr_matrix
        Second matrix to compare.
    max_bins : int
        Maximum distance at which to consider, in bins.
    Returns
    -------
    scc : float
        Stratum adjusted correlation coefficient.
    """

    if max_bins < 0 or max_bins > int(mat1.shape[0] - 5):
        max_bins = int(mat1.shape[0] - 5)

    mat1 = csr_matrix(mat1)
    mat2 = csr_matrix(mat2)
    corr_diag = np.zeros(len(range(max_bins)))
    weight_diag = corr_diag.copy()
    for d in range(max_bins):
        d1 = mat1.diagonal(d)
        d2 = mat2.diagonal(d)
        mask = (~np.isnan(d1)) & (~np.isnan(d2))
        d1 = d1[mask]
        d2 = d2[mask]
        # Silence NaN warnings: this happens for empty diagonals and will
        # not be used in the end.
        with warnings.catch_warnings():
            warnings.filterwarnings(
                "ignore", category=PearsonRConstantInputWarning
            )
            # Compute raw pearson coeff for this diag
            # corr_diag[d] = ss.pearsonr(d1, d2)[0]
            cor = pearsonr(d1, d2)[0]
            corr_diag[d] = cor
        # corr_diag[d] = spearmanr(d1, d2)[0]
        # Compute weight for this diag
        r2k = vstrans(d1, d2)
        weight_diag[d] = len(d1) * r2k
    corr_diag, weight_diag = corr_diag[1:], weight_diag[1:]
    mask = ~np.isnan(corr_diag)
    corr_diag, weight_diag = corr_diag[mask], weight_diag[mask]
    # Normalize weights
    weight_diag /= sum(weight_diag)
    # Weighted sum of coefficients to get SCCs
    scc = np.nansum(corr_diag * weight_diag)
    return scc, max_bins - np.sum(mask)


def vstrans(d1, d2):
    """
    Variance stabilizing transformation to normalize read counts before computing
    stratum correlation. This normalizes counts so that different strata share similar
    dynamic ranges.
    Parameters
    ----------
    d1 : numpy.array of floats
        Diagonal of the first matrix.
    d2 : numpy.array of floats
        Diagonal of the second matrix.
    Returns
    -------
    r2k : numpy.array of floats
        Array of weights to use to normalize counts.
    """
    # Get ranks of counts in diagonal
    ranks_1 = np.argsort(d1) + 1
    ranks_2 = np.argsort(d2) + 1
    # Scale ranks betweeen 0 and 1
    nranks_1 = ranks_1 / max(ranks_1)
    nranks_2 = ranks_2 / max(ranks_2)
    nk = len(ranks_1)
    r2k = np.sqrt(np.var(nranks_1 / nk) * np.var(nranks_2 / nk))
    return r2k


def load_q(a):
    b = []
    with open(a, 'r', encoding='utf-8') as f:
        while True:
            line = f.readline()
            if not line:
                break;
            a = line.strip().split()
            '''if(a[0] >= a[1]):
                break'''
            b.append(a)
    return b

def load_scc(a):
    b = {}
    with open(a, 'r', encoding='utf-8') as f:
        while True:
            line = f.readline()
            if not line:break
            a = line.strip().split()
            b[(a[0]), int(a[4]) // 1500] = [float(a[1]), float(a[2])]
    '''with open(a, 'r', encoding='utf-8') as f:
        while True:
            x = {}
            line = f.readline()
            if not line:break
            a = line.strip().split()
            x[int(a[4]) // 1500] = [float(a[1]), float(a[2])]
            b[a[0]] = x'''
    return b

if __name__ == '__main__':
    r_n_scc = load_scc('scc_20000_1500.txt')
    raw = np.zeros((9, 20))
    node2vec = np.zeros((9, 20))
    i = 0
    for key in r_n_scc.keys():
        raw[key[1]][int(key[0])] = r_n_scc[key][0]
        node2vec[key[1]][int(key[0])] = r_n_scc[key][1]
        i+=1

    #raw = np.argwhere(raw)
    #node2vec = np.argwhere(node2vec)
    '''b1 = load_q('p_5.txt')
    b2 = load_q('p_10.txt')
    b3 = load_q('p_20.txt')
    b4 = load_q('p_50.txt')'''
    plt.figure(figsize=(40, 20), dpi=300)
    '''a = []
    b = []
    for i in range(len(b1)):
        a.append(round(float(b1[i][0]), 2))
        b.append(round(float(b1[i][1]), 2))
    raw[0, : len(b1)] = a
    node2vec[0, : len(b1)] = b
    a = []
    b = []
    for i in range(len(b2)):
        a.append(round(float(b2[i][0]), 2))
        b.append(round(float(b2[i][1]), 2))
    raw[1, : len(b2)] = a
    node2vec[1, : len(b2)] = b
    a = []
    b = []
    for i in range(len(b3)):
        a.append(round(float(b3[i][0]), 2))
        b.append(round(float(b3[i][1]), 2))
    raw[2, : len(b3)] = a
    node2vec[2, : len(b3)] = b
    a = []
    b = []
    for i in range(len(b4)):
        a.append(round(float(b4[i][0]), 2))
        b.append(round(float(b4[i][1]), 2))
    raw[3, : len(b4)] = a
    node2vec[3, : len(b4)] = b'''
    plt.rc('font', family='Times New Roman', size=15)
    for i in range(20):
        if raw[0][i] > 0.0001:
            plt.boxplot(raw[0], labels=['0-1500'], positions=[0.1])
            plt.boxplot(node2vec[0], labels=[' '], positions=[0.25])
        if raw[1][i] > 0:
            plt.boxplot(raw[1], labels=['1500-3000'], positions=[1.1])
            plt.boxplot(node2vec[1], labels=[''], positions=[1.25])
        if raw[2][i] > 0:
            plt.boxplot(raw[2], labels=['3000-4500'], positions=[2.1])
            plt.boxplot(node2vec[2], labels=[''], positions=[2.25])
        if raw[3][i] > 0:
            plt.boxplot(raw[3], labels=['4500-6000'], positions=[3.1])
            plt.boxplot(node2vec[3], labels=[''], positions=[3.25])
        if raw[4][i] > 0:
            plt.boxplot(raw[4], labels=['6000-7500'], positions=[4.1])
            plt.boxplot(node2vec[4], labels=[''], positions=[4.25])
        if raw[5][i] > 0:
            plt.boxplot(raw[5], labels=['7500-9000'], positions=[5.1])
            plt.boxplot(node2vec[5], labels=[''], positions=[5.25])
        if raw[6][i] > 0:
            plt.boxplot(raw[6], labels=['9000-10500'], positions=[6.1])
            plt.boxplot(node2vec[6], labels=[''], positions=[6.25])
        '''if raw[7][i] >= 0:

            plt.boxplot(raw[7], labels=['10500-12000'], showmeans=True, positions=[7.1])
            plt.boxplot(node2vec[7], labels=[''], showmeans=True, positions=[7.25])
        if raw[8][i] >= 0:

            plt.boxplot(raw[8], labels=['12000-13500'], showmeans=True, positions=[8.1])
            plt.boxplot(node2vec[8], labels=[''], showmeans=True, positions=[8.25])'''
    #plt.legend(loc='best')
    #plt.xticks(range(0, len(b), 5))
    #plt.grid(True, linestyle='--', alpha=0.5)
    plt.tick_params(labelsize=10)
    plt.xlabel("resolution(kb)", fontdict={'size': 10})
    plt.ylabel("scc", fontdict={'size': 10})
    plt.title("raw vs node2vec under different cell population", fontdict={'size': 12})
    plt.show()
    plt.close()